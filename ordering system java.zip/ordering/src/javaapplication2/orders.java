/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.Image;
import java.awt.Insets;
import java.awt.List;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Blob;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.filechooser.FileNameExtensionFilter;

        

/**
 *
 * @author Criz
 */
public class orders extends javax.swing.JFrame {
Connection conn = null;
PreparedStatement pst = null;
ResultSet rst = null;
byte[] person_image = null;
 String productStatusId;

    /**
     * Creates new form orders
     */
    public orders() {
        initComponents();
        
        //ListOfProduct();
    }
    
    public void getStatusID(){
       String productStatus = cmb_product_status.getSelectedItem().toString();
      
       if(productStatus.equals("Available")){
       productStatusId = "1";
       }
       else if(productStatus.equals("Not Available")){
       productStatusId = "2";
      }
    }
    
    
     public void ListOfProduct(){
            int size = 0;
         try
         {
             String sql = "SELECT * FROM PRODUCT";
             conn =DbConnect.DBConnect();
             pst = conn.prepareStatement(sql);
             rst = pst.executeQuery();
//             if(rst.next()){      
               
                byte b[];
                Blob blob;
                
                
                while(rst.next())
                {
                   
                  productInfo ProductMenu = new productInfo();
                
                      
                      String name = rst.getString("productName");
                 int dbCountRow = rst.getInt("productId");
                 String db_getProductName = rst.getString("productName");
                 int db_getProductPrice = rst.getInt("price");
                 byte[]db_getproductimage = rst.getBytes("picture");
                
                 panelBlue.setLayout(new FlowLayout(FlowLayout.LEFT));
                 panelBlue.setLayout (new BoxLayout(panelBlue, BoxLayout.X_AXIS));  
                 panelBlue.setSize(10, 10); 
                 
                //  jPanel4.setLayout()
          //  jPanel4.setLayout(new BoxLayout(jPanel4, BoxLayout.Y_AXIS));
               
                  ImageIcon icon =  new ImageIcon(new ImageIcon(db_getproductimage).getImage().getScaledInstance(lblImages.getWidth(), lblImages.getHeight(), Image.SCALE_SMOOTH));         
//                     
                  
                blob=rst.getBlob("picture");
                 b=blob.getBytes(1, (int)blob.length());
                panelBlue.add(ProductMenu);   
                  ProductMenu.setimages(icon);
               ProductMenu.setProductName(db_getProductName);
               ProductMenu.setProductPrice(db_getProductPrice);
                  size++;
                  
                 System.out.print("ID: " + rst.getInt(1));
                 System.out.print(" Product : "+rst.getString("productName"));
                 System.out.println(" Price : "+rst.getString("price"));

               // }
     /////MAIN PROGRAM
//                 rst.last();
//                 size = rst.getRow();
//                 
//                 if(size>0){                         
//                    GridBagConstraints gbc = new GridBagConstraints();
//                    gbc.insets = new Insets(20,20,20,20);
//                    int x = 0,y = 0;
//                    gbc.gridx = 0;
//                    gbc.gridy =0; 
//                    productInfo[] productList = new productInfo[size];
//                       ImageIcon imIcon = new ImageIcon(rst.getBytes("images"));
//                       for(int i =0; i<imIcon.;i++ )
//                       {
//                           productInfo ProductMenu = new productInfo();
//                           String url = "";
//                        
//                            ImageIcon icon =  new ImageIcon(new ImageIcon(db_getproductimage).getImage().getScaledInstance(lbl_image.getWidth(), lbl_image.getHeight(), Image.SCALE_SMOOTH));         
//                     
//                            gbc.gridx = x;
//                            gbc.gridy = y;
//                           // ProductMenu.setProductPrice(rst.getInt("price"));
//                            ProductMenu.setimages(new ImageIcon(list[i].getAbsolutePath()));
//                            jPanel4.add(ProductMenu,gbc);        
//                             x++;
//                             if(x == 3)
//                             {
//                                 x = 0;
//                                 y++;
//                             
//                            }
     //    }
                     //  }
                       
                 }         
             //}
         }
         catch(Exception e)
         {
             System.out.println("Error" + e);
         }
    }
     
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        product_name = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        product_description = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        product_quantity = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        product_price = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        cmb_categories = new javax.swing.JComboBox<>();
        jButton3 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        cmb_product_status = new javax.swing.JComboBox<>();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        lblImages = new javax.swing.JLabel();
        picture_path = new javax.swing.JLabel();
        panelRed = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        blue = new javax.swing.JPanel();
        red = new javax.swing.JPanel();
        panelBlue = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("add product");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 20, 110, 40));

        jButton1.setText("exit");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 20, -1, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setText("Product name:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, -1, -1));
        jPanel1.add(product_name, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 30, 190, -1));

        jLabel5.setText("Product Description:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, -1, -1));
        jPanel1.add(product_description, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 60, 190, -1));

        jLabel4.setText("Product Quantity:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, -1, -1));
        jPanel1.add(product_quantity, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 90, 190, -1));

        jLabel6.setText("Price:");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, -1, -1));
        jPanel1.add(product_price, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 120, 190, -1));

        jLabel7.setText("Categories :");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 150, -1, -1));

        jLabel8.setText("Status:");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 180, -1, -1));

        cmb_categories.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choose" }));
        jPanel1.add(cmb_categories, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 150, 190, -1));

        jButton3.setText("insert");
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3MouseClicked(evt);
            }
        });
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 230, -1, -1));

        jButton2.setText("getPicture");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 150, -1, -1));

        cmb_product_status.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choose:", "Available", "Not Available" }));
        jPanel1.add(cmb_product_status, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 180, 190, -1));

        jButton5.setText("retrive image");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 240, -1, -1));

        jButton6.setText("jButton6");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 240, -1, -1));

        lblImages.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblImages.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblImages.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel1.add(lblImages, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 20, 190, 120));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 690, 270));
        getContentPane().add(picture_path, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 150, 140, 40));

        panelRed.setBackground(new java.awt.Color(255, 0, 51));
        panelRed.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panelRedMouseClicked(evt);
            }
        });
        getContentPane().add(panelRed, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 460, 160, 40));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new java.awt.CardLayout());

        blue.setBackground(new java.awt.Color(153, 204, 255));
        jPanel2.add(blue, "card2");

        red.setBackground(new java.awt.Color(255, 51, 0));
        jPanel2.add(red, "card3");

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 350, 480, 290));

        panelBlue.setBackground(new java.awt.Color(204, 0, 255));
        panelBlue.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panelBlueMouseClicked(evt);
            }
        });
        getContentPane().add(panelBlue, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 390, 160, 40));

        setSize(new java.awt.Dimension(748, 685));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        panelBlue.setLayout(new FlowLayout(FlowLayout.LEFT ,15, 15));
        lblImages.getSize();
        try{
            conn = DbConnect.DBConnect();
            String query = "SELECT * FROM Categories";
            pst = conn.prepareStatement(query);
            rst = pst.executeQuery();
            while(rst.next()){
               cmb_categories.addItem(rst.getString("categoriesName"));
            }
            rst.close();
        }catch(Exception e){
            System.out.println("Error" + e);
        }
    }//GEN-LAST:event_formWindowOpened

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        ListOfProduct();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        try{
            String query = "SELECT *  FROM product WHERE productId = 1";
            conn = DbConnect.DBConnect();
            pst = conn.prepareStatement(query);
            rst = pst.executeQuery();
            if(rst.next()){
                //byte[] img =

                byte[] db_product_image = rst.getBytes("picture");
                ImageIcon icon =  new ImageIcon(new ImageIcon(db_product_image).getImage().getScaledInstance(lblImages.getWidth(), lblImages.getHeight(), Image.SCALE_SMOOTH));
                lblImages.setIcon(icon);
            }
        }catch(Exception e){
            System.out.println("Error" + e);
        }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
        FileNameExtensionFilter fileExtension  = new FileNameExtensionFilter("*,.image,","jpg","gif","png");
        fileChooser.addChoosableFileFilter(fileExtension);
        int result = fileChooser.showSaveDialog(null);
        if(result == JFileChooser.APPROVE_OPTION){
            File selectedFile = fileChooser.getSelectedFile();
            String path = selectedFile.getAbsolutePath();
            picture_path.setText(path);
            ImageIcon icon =  new ImageIcon(new ImageIcon(path).getImage().getScaledInstance(lblImages.getWidth(), lblImages.getHeight(), Image.SCALE_SMOOTH));
            lblImages.setIcon(icon);
            try{
                File image = new File(path);
                FileInputStream FileInput =  new FileInputStream(image);
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                byte[] buf =  new byte[1024];
                for(int readNum; (readNum = FileInput.read(buf))!= -1;){
                    bos.write(buf,0,readNum);
                    person_image = bos.toByteArray();
                }
            }catch(Exception e){
                JOptionPane.showMessageDialog(null,"Error" +e);
            }
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if(product_name.getText().isEmpty() | product_description.getText().isEmpty() | product_quantity.getText().isEmpty()|
            product_price.getText().isEmpty()| cmb_categories.getSelectedIndex() == 0 | cmb_product_status.getSelectedIndex() == 0)
        {
            JOptionPane.showMessageDialog(null,"All form must be Filled up");
        }
        else{
            try{
                getStatusID(); //GETTING STATUS ID

                String categories = cmb_categories.getSelectedItem().toString();
                String catID;

                conn = DbConnect.DBConnect();
                String query = "SELECT * FROM CATEGORIES WHERE CategoriesName = ? ";

                pst = conn.prepareStatement(query);
                pst.setString(1,categories);
                rst = pst.executeQuery();
                if(rst.next()){
                    catID = rst.getString("categoriesID");

                    String productquery = "INSERT INTO `product`( `categoriesID`, `productName`, `productDescription`, `productQuantity`, `price`, `productStatus`, `picture`) "
                    + "VALUES (?,?,?,?,?,?,?) ";
                    conn = DbConnect.DBConnect();
                    pst  = conn.prepareStatement(productquery);
                    pst.setString(1,catID);
                    pst.setString(2, product_name.getText());
                    pst.setString(3,product_description.getText());
                    pst.setString(4,product_quantity.getText());
                    pst.setString(5,product_price.getText());
                 //   pst.setString(5,catID)
                    pst.setString(6,productStatusId); 
                    pst.setBytes(7,person_image);
                    int i = pst.executeUpdate();

                    if(i>0){
                        JOptionPane.showMessageDialog(null,"Successfully inserted");
                        panelBlue.removeAll();
                        ListOfProduct();
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null,"Please check all the details before inserting");
                    }
                }

            }catch(Exception e){
                System.out.println("Error" + e);
            }
        }

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseClicked
        try{
            String query = "SELECT *  FROM product WHERE productId = 1";
            conn = DbConnect.DBConnect();
            pst = conn.prepareStatement(query);
            rst = pst.executeQuery();
            if(rst.next()){
                //byte[] img =

                byte[] db_product_image = rst.getBytes("picture");
                ImageIcon icon =  new ImageIcon(new ImageIcon(db_product_image).getImage().getScaledInstance(lblImages.getWidth(), lblImages.getHeight(), Image.SCALE_SMOOTH));
                lblImages.setIcon(icon);
            }
        }catch(Exception e){
            System.out.println("Error" + e);
        }
    }//GEN-LAST:event_jButton3MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        userControlPanel MainForm = new userControlPanel();
        MainForm.validate();
        // MainForm.show();
        MainForm.validate();
        //MainForm.repaint();
        //this.dispose();
        MainForm.enable(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void panelBlueMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelBlueMouseClicked
           //newOrderPanel.setVisible(true);
        jPanel2.removeAll();
        jPanel2.repaint();
        jPanel2.revalidate();
        //ADD PANEL
        jPanel2.add(blue);
        jPanel2.repaint();
        jPanel2.revalidate();
    }//GEN-LAST:event_panelBlueMouseClicked

    private void panelRedMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelRedMouseClicked
        jPanel2.removeAll();
        jPanel2.repaint();
        jPanel2.revalidate();
        //ADD PANEL
        jPanel2.add(red);
        jPanel2.repaint();
        jPanel2.revalidate();
    }//GEN-LAST:event_panelRedMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(orders.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(orders.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(orders.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(orders.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new orders().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JPanel blue;
    private javax.swing.JComboBox<String> cmb_categories;
    private javax.swing.JComboBox<String> cmb_product_status;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    protected static javax.swing.JPanel jPanel2;
    public static javax.swing.JLabel lblImages;
    private javax.swing.JPanel panelBlue;
    private javax.swing.JPanel panelRed;
    private javax.swing.JLabel picture_path;
    private javax.swing.JTextField product_description;
    private javax.swing.JTextField product_name;
    private javax.swing.JTextField product_price;
    private javax.swing.JTextField product_quantity;
    public static javax.swing.JPanel red;
    // End of variables declaration//GEN-END:variables
}
