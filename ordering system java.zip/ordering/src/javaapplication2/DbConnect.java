/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Criz
 */
public class DbConnect {
   // Connection conn;
    private PreparedStatement insertIntoUsers;
    private PreparedStatement queryUserByUsernameAndPassword;
    private PreparedStatement updateUserById;

    private PreparedStatement insertIntoMovies;
    private PreparedStatement updateMovieById;
    private PreparedStatement deleteMovieById;

    private PreparedStatement insertIntoSeats;

    private PreparedStatement insertIntoBookShows;
    private PreparedStatement deleteBookshowById;
    private PreparedStatement bookingHistoryByUserId;

    private Connection conn;
    private static DbConnect instance = new DbConnect();
  
    private DbConnect(){

    }///CONNECTION
    public static DbConnect getInstance(){
        return instance;
    }
   public static Connection DBConnect(){
       try
       {
          Class.forName("com.mysql.cj.jdbc.Driver");
          Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/orderingsystem","root","");
          return conn;        
       }catch(Exception e)
       {
           System.out.println("Please Connect to the DatabaseS" + e);
       }
        return null;     
   }

}

