/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import javax.swing.JOptionPane;


/**
 *
 * @author Criz
 */
public class Products {

    public static void main(String[] args){
        
         String names[] = {"abc","def"};
              
                  for(int k = 0;k<names.length;k++){
                        
                      for(int j = k+1; j<names.length;j++){
                          
                          if(names[k]== names[j]){
                              
                               JOptionPane.showMessageDialog(null, names[k]);
                          }else{
                              JOptionPane.showMessageDialog(null, "none");
                          }
                         
//                        if(names[k].equals(j)){
//                            
//                        }
                      }
                    }
    }




  
}

