/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Label;
import java.awt.LayoutManager;
import java.awt.Panel;
import java.awt.RenderingHints;
import java.awt.event.ActionListener;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import static java.lang.System.in;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import static javax.swing.JTable.AUTO_RESIZE_OFF;
import javax.swing.Timer;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;
import static sun.security.util.Debug.Help;


/**
 *
 * @author Criz
 */
public class userControlPanel extends javax.swing.JFrame {
    GridBagLayout layout = new GridBagLayout();
    GridBagLayout layout1 = new GridBagLayout();
    Label user;
   // Label dbEmployeeID ;
    Panel m_dashboard1 ;
    Panel m_orders2;
    byte[] person_image = null;
    Connection conn = null;
    PreparedStatement pst = null;
    ResultSet rst = null;
    String productStatusId;
    String s = "sample";
    public int dbID;
     int db_NumberOfOrders,db_CountOrders;
      String db_OrderStatus;
      String sqlsort ="";
    //Panel newOrderPanel;
    
    /**
     * Creates new form mainMenu
     */
    public userControlPanel() {
        initComponents();
      
        mainpanel.setLayout(layout);
       // a = dbEmployeeID.setText("");
        GridBagConstraints c = new GridBagConstraints();
        //GridBagConstraints d = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        mainpanel.add(m_dashboard,c);
        c.gridx = 0;
        c.gridy = 0;
        mainpanel.add(m_orders,c);
        c.gridx = 0;
        c.gridy = 0;
        mainpanel.add(m_products,c);
        c.gridx = 0;
        c.gridy = 0;
        mainpanel.add(m_users,c);
        c.gridx = 0;
        c.gridy = 0;
        mainpanel.add(m_promo,c);
        c.gridx = 0;
        c.gridy = 0;
        mainpanel.add(m_reports,c);
        c.gridx = 0;
        c.gridy = 0;
        mainpanel.add(m_settings,c);
     
        m_dashboard.setVisible(true);
        m_orders.setVisible(false);
        m_products.setVisible(false);
        m_users.setVisible(false);
        m_promo.setVisible(false);
        m_reports.setVisible(false);
        m_settings.setVisible(false);
        
//        fetchProduct();
        fetchCategory();
        getOrderNumberAndStatus();
  
    }
    //GET EMPLOYEE ID
    public void getEmployeeID(){
       String getEmployeeName = lblEmployeeName.getText();
       getEmployeeName = getEmployeeName.replaceAll("\\s+", "");
        try{
            String query = "SELECT * FROM `employee` WHERE concat(firstName,lastName)= ?";
            conn = DbConnect.DBConnect();
            pst = conn.prepareStatement(query);
            pst.setString(1, getEmployeeName);
            rst =pst.executeQuery();
            while(rst.next()){
                 dbID = rst.getInt("employeeId");
            }
        }catch(Exception e){
            System.out.println("Error" + e);
        }
    }
    //FETCH PRODUCT
//    public void fetchProduct(){
//        conn = DbConnect.DBConnect();
//        String sql = "SELECT productName,productQuantity,price,productStatus,categoriesName from "
//                      + "PRODUCT join categories on categories.categoriesID = product.categoriesID order by productName ";
//        
//        try{
//            DefaultTableModel model = (DefaultTableModel) productTable.getModel();
//            model.setRowCount(0);
//            pst = conn.prepareStatement(sql);
//            rst = pst.executeQuery();
//            while(rst.next()){
//               String[] details = {"productName","productQuantity","price","CategoriesName"};
//               String[] detail =  {"productName","productQuantity","price","CategoriesName"};
//
//                   for(int i=0; i < details.length;i++){
//                    details[i] = rst.getString(detail[i]);
//
//                }
//                Object[] row={details[0],details[1],details[2],details[3]};
//
//                model.addRow(row);
//            }
//        }catch(Exception ex){
//            System.out.println("ERROR"+ex);
//        
//        }
//      }
    //FETCH CATEGORY NAME
      public void fetchCategory(){
        try{
            conn = DbConnect.DBConnect();
            String query = "SELECT * FROM Categories";
            pst = conn.prepareStatement(query);
            rst = pst.executeQuery();
            while(rst.next()){
               cmb_categories.addItem(rst.getString("categoriesName"));
              
            }
            rst.close();
        }catch(Exception e){
            System.out.println("Error" + e);
        }
      }
    public void getStatusID(){
       if(productStatusId.equals("Available")){
       productStatusId = "1";
       }
       else if(productStatusId.equals("Not Available")){
       productStatusId = "2";
       
      }
    }
    //EMPLOYEE ID
    public int getID(){
        return dbID;
    }
    public void setProductName(int employeeID){
        this.dbID = employeeID;
    }
   
    
     public void getOrderNumberAndStatus(){
        
           DefaultTableModel model = (DefaultTableModel)listOfNewOrders.getModel();
        String sql = "SELECT DISTINCT(orderDetails.orderNumber)as NumberOfOrders,orderstatus.OrderStatus FROM `orderdetails` \n" +
"                         JOIN orderstatus ON orderdetails.orderStatusID = orderstatus.orderStatusID \n" +
"                          JOIN payment on orderdetails.orderID = payment.orderID where orderstatus.orderStatusID =4;";
        try{
            String[] details,detail;
            //model.setRowCount(0);
            conn = DbConnect.DBConnect();
            pst = conn.prepareStatement(sql);
            rst = pst.executeQuery();
            int num = 0;
            while(rst.next()){
               db_NumberOfOrders = rst.getInt("NumberOfOrders");
               db_OrderStatus = rst.getString("OrderStatus");
            
              model.addRow(new Object [] {db_NumberOfOrders,db_OrderStatus,db_CountOrders});
           
            }
              }catch(Exception e){
            System.out.println("Error" + e);
        }

    }
    public void refreshNewOrders(){
        DefaultTableModel model =  (DefaultTableModel)listOfNewOrders.getModel();
        model.setRowCount(0);
        getOrderNumberAndStatus();
    }
                                            
    public void sortProducts(){
         try{
            jPanel29.removeAll();
            String sortingProduct = cmbSort.getSelectedItem().toString();
            if(sortingProduct.equals("Ascending")){
                sqlsort = "SELECT * FROM product ORDER BY productName ASC";
                System.out.println(sqlsort);
            }else if(sortingProduct.equals("Descending")){
                sqlsort = "SELECT * FROM product ORDER BY productName DESC";
                System.out.println(sqlsort);
            }
           conn = DbConnect.DBConnect();
           pst =conn.prepareStatement(sqlsort);
          
           rst =pst.executeQuery();
           GridBagConstraints gbc = new GridBagConstraints();
                    gbc.insets = new Insets(10,10,10,10);
                    int x = 0,y = 0;
                    gbc.gridx = 0;
                    gbc.gridy =0; 
                    int result = 1;
           while(rst.next()){
               gbc.gridx = x; gbc.gridy = y;
                    productInfo p = new productInfo();
                    jPanel29.add(p,gbc);
                   result++;
                    String dbProductName = rst.getString("productName");
                    byte []dbProductImage = rst.getBytes("picture");
                    ImageIcon icon =  new ImageIcon(new ImageIcon(dbProductImage).getImage()
                    .getScaledInstance(150,100, Image.SCALE_SMOOTH));  
                    
                    p.setProductName(dbProductName);
                    p.setProductPrice(rst.getInt("price"));
                    p.setimages(icon);

                    x++;
                    if(x == 3){
                        x=0;
                        y++;
                    }
           }
           
       }catch(Exception e){
           System.out.println("Error" + e);
       }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel28 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        menu = new javax.swing.JPanel();
        dashboard_panel = new javax.swing.JPanel();
        lbl_dashboard = new javax.swing.JLabel();
        dash_hover = new javax.swing.JPanel();
        icon_dashboard = new javax.swing.JLabel();
        icon_dashboardWhite = new javax.swing.JLabel();
        order_panel = new javax.swing.JPanel();
        lbl_orders = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        orders_hover = new javax.swing.JPanel();
        jLabel43 = new javax.swing.JLabel();
        product_panel = new javax.swing.JPanel();
        lbl_products = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        product_hover = new javax.swing.JPanel();
        jLabel44 = new javax.swing.JLabel();
        user_panel = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        users_hover = new javax.swing.JPanel();
        jLabel45 = new javax.swing.JLabel();
        lbl_users = new javax.swing.JLabel();
        promo_panel = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        pc_hover = new javax.swing.JPanel();
        jLabel46 = new javax.swing.JLabel();
        lbl_promocode = new javax.swing.JLabel();
        reports_panel = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        report_hover = new javax.swing.JPanel();
        jLabel47 = new javax.swing.JLabel();
        lbl_reports = new javax.swing.JLabel();
        settings_panel = new javax.swing.JPanel();
        lbl_settings = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        settings_hover = new javax.swing.JPanel();
        jLabel48 = new javax.swing.JLabel();
        lblEmployeeName = new javax.swing.JLabel();
        mainpanel = new javax.swing.JPanel();
        m_dashboard = new javax.swing.JPanel();
        jPanel21 = new javax.swing.JPanel();
        jPanel23 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        jPanel18 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jPanel19 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jPanel24 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        m_orders = new javax.swing.JPanel();
        mainOrderPanel = new javax.swing.JPanel();
        nOrderPanel = new javax.swing.JPanel();
        btn_group = new javax.swing.JPanel();
        btn_newOrders = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        btn_inProgress = new javax.swing.JPanel();
        jLabel57 = new javax.swing.JLabel();
        btn_cancelled = new javax.swing.JPanel();
        jLabel58 = new javax.swing.JLabel();
        btn_completed = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        tabpanel = new javax.swing.JPanel();
        newOrders = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jTextField3 = new javax.swing.JTextField();
        jButton8 = new javax.swing.JButton();
        jLabel34 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        listOfNewOrders = new javax.swing.JTable();
        jPanel25 = new javax.swing.JPanel();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jButton16 = new javax.swing.JButton();
        inProgress_panel = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jTextField4 = new javax.swing.JTextField();
        jButton9 = new javax.swing.JButton();
        jLabel35 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblProcessOrders = new javax.swing.JTable();
        jPanel22 = new javax.swing.JPanel();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        cancelled_panel = new javax.swing.JPanel();
        jPanel26 = new javax.swing.JPanel();
        jTextField5 = new javax.swing.JTextField();
        jButton17 = new javax.swing.JButton();
        jLabel36 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable5 = new javax.swing.JTable();
        jPanel32 = new javax.swing.JPanel();
        jButton27 = new javax.swing.JButton();
        jButton30 = new javax.swing.JButton();
        jButton31 = new javax.swing.JButton();
        completed_panel = new javax.swing.JPanel();
        jPanel30 = new javax.swing.JPanel();
        jTextField7 = new javax.swing.JTextField();
        jButton25 = new javax.swing.JButton();
        jLabel38 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTable7 = new javax.swing.JTable();
        jPanel31 = new javax.swing.JPanel();
        jButton26 = new javax.swing.JButton();
        jButton28 = new javax.swing.JButton();
        jButton29 = new javax.swing.JButton();
        m_products = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        picture_path = new javax.swing.JLabel();
        producMainPanel = new javax.swing.JPanel();
        panelAddProduct = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jLabel59 = new javax.swing.JLabel();
        product_name1 = new javax.swing.JTextField();
        jLabel60 = new javax.swing.JLabel();
        product_description1 = new javax.swing.JTextField();
        jLabel61 = new javax.swing.JLabel();
        product_quantity1 = new javax.swing.JTextField();
        jLabel62 = new javax.swing.JLabel();
        product_price1 = new javax.swing.JTextField();
        jLabel63 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        cmb_categories = new javax.swing.JComboBox<>();
        jButton19 = new javax.swing.JButton();
        jButton20 = new javax.swing.JButton();
        lblImages1 = new javax.swing.JLabel();
        jRadioButton3 = new javax.swing.JRadioButton();
        jRadioButton4 = new javax.swing.JRadioButton();
        jButton21 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        panelAddCategories = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jLabel51 = new javax.swing.JLabel();
        product_name = new javax.swing.JTextField();
        jLabel52 = new javax.swing.JLabel();
        product_description = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        lblImages = new javax.swing.JLabel();
        jButton18 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        jPanel27 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        cmbSort = new javax.swing.JComboBox<>();
        jTextField6 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jPanel15 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel29 = new javax.swing.JPanel();
        m_promo = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        listofOrderPanel1 = new javax.swing.JPanel();
        jScrollPane8 = new javax.swing.JScrollPane();
        productTable1 = new javax.swing.JTable();
        txt_search1 = new javax.swing.JTextField();
        jButton7 = new javax.swing.JButton();
        jComboBox2 = new javax.swing.JComboBox<>();
        jLabel17 = new javax.swing.JLabel();
        m_users = new javax.swing.JPanel();
        jPanel33 = new javax.swing.JPanel();
        leaveBtn = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jPanel34 = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        userBtn = new javax.swing.JPanel();
        jLabel29 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jPanel37 = new javax.swing.JPanel();
        jLabel37 = new javax.swing.JLabel();
        departmentBtn = new javax.swing.JPanel();
        jLabel42 = new javax.swing.JLabel();
        jPanel40 = new javax.swing.JPanel();
        jLabel71 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        noticeBtn = new javax.swing.JPanel();
        jLabel75 = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        jPanel43 = new javax.swing.JPanel();
        jLabel77 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel9 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jButton5 = new javax.swing.JButton();
        m_reports = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        m_settings = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        lblNumbeOfOrders = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();

        javax.swing.GroupLayout jPanel28Layout = new javax.swing.GroupLayout(jPanel28);
        jPanel28.setLayout(jPanel28Layout);
        jPanel28Layout.setHorizontalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel28Layout.setVerticalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);
        setType(java.awt.Window.Type.UTILITY);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        menu.setBackground(new java.awt.Color(139, 69, 19));
        menu.setForeground(new java.awt.Color(172, 73, 45));
        menu.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        dashboard_panel.setBackground(new java.awt.Color(153, 153, 255));
        dashboard_panel.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        dashboard_panel.setForeground(new java.awt.Color(255, 255, 255));
        dashboard_panel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        dashboard_panel.setOpaque(false);
        dashboard_panel.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                dashboard_panelFocusGained(evt);
            }
        });
        dashboard_panel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dashboard_panelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                dashboard_panelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                dashboard_panelMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                dashboard_panelMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                dashboard_panelMouseReleased(evt);
            }
        });
        dashboard_panel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                dashboard_panelKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                dashboard_panelKeyReleased(evt);
            }
        });
        dashboard_panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbl_dashboard.setBackground(new java.awt.Color(1, 1, 251));
        lbl_dashboard.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lbl_dashboard.setForeground(new java.awt.Color(236, 211, 191));
        lbl_dashboard.setText("Dashboard");
        dashboard_panel.add(lbl_dashboard, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 0, 140, 40));

        dash_hover.setBackground(new java.awt.Color(255, 255, 255));
        dash_hover.setMinimumSize(new java.awt.Dimension(5, 50));
        dash_hover.setPreferredSize(new java.awt.Dimension(3, 50));
        dash_hover.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        dashboard_panel.add(dash_hover, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 40));

        icon_dashboard.setBackground(new java.awt.Color(255, 255, 255));
        icon_dashboard.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/dashboard.png"))); // NOI18N
        dashboard_panel.add(icon_dashboard, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, -1, 40));

        icon_dashboardWhite.setBackground(new java.awt.Color(255, 255, 255));
        icon_dashboardWhite.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/dashWhite.png"))); // NOI18N
        dashboard_panel.add(icon_dashboardWhite, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, -1, 40));

        menu.add(dashboard_panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 230, 40));

        order_panel.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        order_panel.setForeground(new java.awt.Color(255, 255, 255));
        order_panel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        order_panel.setOpaque(false);
        order_panel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                order_panelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                order_panelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                order_panelMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                order_panelMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                order_panelMouseReleased(evt);
            }
        });
        order_panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbl_orders.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lbl_orders.setForeground(new java.awt.Color(236, 211, 191));
        lbl_orders.setLabelFor(m_orders);
        lbl_orders.setText("Orders");
        lbl_orders.setRequestFocusEnabled(false);
        order_panel.add(lbl_orders, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 0, 140, 40));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/orders.png"))); // NOI18N
        order_panel.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, 40, 40));

        orders_hover.setBackground(new java.awt.Color(255, 255, 255));
        orders_hover.setMinimumSize(new java.awt.Dimension(5, 50));
        orders_hover.setPreferredSize(new java.awt.Dimension(3, 50));
        orders_hover.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        order_panel.add(orders_hover, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 40));

        jLabel43.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/cartWhite.png"))); // NOI18N
        order_panel.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, -1, 40));

        menu.add(order_panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 230, 40));

        product_panel.setBackground(new java.awt.Color(153, 51, 255));
        product_panel.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        product_panel.setForeground(new java.awt.Color(255, 255, 255));
        product_panel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        product_panel.setOpaque(false);
        product_panel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                product_panelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                product_panelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                product_panelMouseExited(evt);
            }
        });
        product_panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbl_products.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lbl_products.setForeground(new java.awt.Color(236, 211, 191));
        lbl_products.setText("Products");
        product_panel.add(lbl_products, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 0, 140, 40));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/products.png"))); // NOI18N
        product_panel.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, -1, 40));

        product_hover.setBackground(new java.awt.Color(255, 255, 255));
        product_hover.setMinimumSize(new java.awt.Dimension(5, 50));
        product_hover.setPreferredSize(new java.awt.Dimension(3, 50));
        product_hover.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        product_panel.add(product_hover, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 40));

        jLabel44.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/productWHite.png"))); // NOI18N
        product_panel.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, -1, 40));

        menu.add(product_panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 230, 40));

        user_panel.setBackground(new java.awt.Color(102, 255, 102));
        user_panel.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        user_panel.setForeground(new java.awt.Color(255, 255, 255));
        user_panel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        user_panel.setOpaque(false);
        user_panel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                user_panelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                user_panelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                user_panelMouseExited(evt);
            }
        });
        user_panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/user.png"))); // NOI18N
        user_panel.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, -1, 40));

        users_hover.setBackground(new java.awt.Color(255, 255, 255));
        users_hover.setMinimumSize(new java.awt.Dimension(5, 50));
        users_hover.setPreferredSize(new java.awt.Dimension(3, 50));
        users_hover.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        user_panel.add(users_hover, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 40));

        jLabel45.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/userWhite.png"))); // NOI18N
        user_panel.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, -1, 40));

        lbl_users.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lbl_users.setForeground(new java.awt.Color(236, 211, 191));
        lbl_users.setText("Users");
        user_panel.add(lbl_users, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 0, 140, 40));

        menu.add(user_panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 210, 230, 40));

        promo_panel.setBackground(new java.awt.Color(204, 255, 204));
        promo_panel.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        promo_panel.setForeground(new java.awt.Color(255, 255, 255));
        promo_panel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        promo_panel.setOpaque(false);
        promo_panel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                promo_panelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                promo_panelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                promo_panelMouseExited(evt);
            }
        });
        promo_panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/promo.png"))); // NOI18N
        promo_panel.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, -1, 40));

        pc_hover.setBackground(new java.awt.Color(255, 255, 255));
        pc_hover.setMinimumSize(new java.awt.Dimension(5, 50));
        pc_hover.setPreferredSize(new java.awt.Dimension(3, 50));
        pc_hover.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        promo_panel.add(pc_hover, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 40));

        jLabel46.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/promoWHite.png"))); // NOI18N
        promo_panel.add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, -1, 40));

        lbl_promocode.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lbl_promocode.setForeground(new java.awt.Color(236, 211, 191));
        lbl_promocode.setText("Promo Code");
        promo_panel.add(lbl_promocode, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 0, 140, 40));

        menu.add(promo_panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 260, 230, 40));

        reports_panel.setBackground(new java.awt.Color(102, 255, 255));
        reports_panel.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        reports_panel.setForeground(new java.awt.Color(255, 255, 255));
        reports_panel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        reports_panel.setOpaque(false);
        reports_panel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                reports_panelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                reports_panelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                reports_panelMouseExited(evt);
            }
        });
        reports_panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/reports.png"))); // NOI18N
        reports_panel.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, -1, 40));

        report_hover.setBackground(new java.awt.Color(255, 255, 255));
        report_hover.setMinimumSize(new java.awt.Dimension(5, 50));
        report_hover.setPreferredSize(new java.awt.Dimension(3, 50));
        report_hover.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        reports_panel.add(report_hover, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 40));

        jLabel47.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/ReportsWhite.png"))); // NOI18N
        reports_panel.add(jLabel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, -1, 40));

        lbl_reports.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lbl_reports.setForeground(new java.awt.Color(236, 211, 191));
        lbl_reports.setText("Reports");
        reports_panel.add(lbl_reports, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 0, 140, 40));

        menu.add(reports_panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 310, 230, 40));

        settings_panel.setBackground(new java.awt.Color(102, 102, 102));
        settings_panel.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        settings_panel.setForeground(new java.awt.Color(255, 255, 255));
        settings_panel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        settings_panel.setOpaque(false);
        settings_panel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                settings_panelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                settings_panelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                settings_panelMouseExited(evt);
            }
        });
        settings_panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbl_settings.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lbl_settings.setForeground(new java.awt.Color(236, 211, 191));
        lbl_settings.setText("Settings");
        settings_panel.add(lbl_settings, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 0, 140, 40));

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/settings.png"))); // NOI18N
        settings_panel.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, -1, 40));

        settings_hover.setBackground(new java.awt.Color(255, 255, 255));
        settings_hover.setMinimumSize(new java.awt.Dimension(5, 50));
        settings_hover.setPreferredSize(new java.awt.Dimension(3, 50));
        settings_hover.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        settings_panel.add(settings_hover, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 40));

        jLabel48.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/settingsWhite.png"))); // NOI18N
        settings_panel.add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, -1, 40));

        menu.add(settings_panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 360, 230, 40));

        lblEmployeeName.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblEmployeeName.setForeground(new java.awt.Color(255, 255, 255));
        lblEmployeeName.setText("criz selga");
        menu.add(lblEmployeeName, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 500, 190, 30));

        jPanel1.add(menu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 230, 550));

        mainpanel.setBackground(new java.awt.Color(255, 255, 255));
        mainpanel.setLayout(new java.awt.CardLayout());

        m_dashboard.setLayout(new java.awt.CardLayout());

        jPanel21.setBackground(new java.awt.Color(255, 255, 255));
        jPanel21.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel23.setBackground(new java.awt.Color(180, 136, 104));
        jPanel23.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel8.setBackground(new java.awt.Color(169, 118, 83));
        jPanel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel8MouseClicked(evt);
            }
        });
        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel18.setFont(new java.awt.Font("SansSerif", 1, 16)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("NEW ORDERS");
        jPanel8.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 140, 50));

        jPanel23.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 220, 50));

        jPanel9.setBackground(new java.awt.Color(169, 118, 83));
        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel19.setFont(new java.awt.Font("SansSerif", 1, 16)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("IN PROGRESS");
        jPanel9.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 120, 50));

        jPanel23.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 20, 220, 50));

        jPanel10.setBackground(new java.awt.Color(169, 118, 83));
        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel21.setFont(new java.awt.Font("SansSerif", 1, 16)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setText("CANCELLED");
        jPanel10.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, 120, 50));

        jPanel23.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 20, 220, 50));

        jPanel18.setBackground(new java.awt.Color(169, 118, 83));
        jPanel18.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel20.setFont(new java.awt.Font("SansSerif", 1, 16)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("COMPLETED");
        jPanel18.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 120, 50));

        jPanel23.add(jPanel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 20, 220, 50));

        jPanel21.add(jPanel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 72, 950, 90));

        jLabel23.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel23.setText("ORDER STATISTICS");
        jPanel21.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 25, -1, -1));

        jPanel19.setBackground(new java.awt.Color(255, 255, 255));
        jPanel19.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        jPanel19.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 920, 270));

        jPanel24.setBackground(new java.awt.Color(255, 255, 255));
        jPanel24.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextField1.setText("Search Here");
        jTextField1.setFocusable(false);
        jPanel24.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 150, 30));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/search.png"))); // NOI18N
        jPanel24.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 0, 30, 50));

        jPanel19.add(jPanel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 30, 210, 50));

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel22.setText("RECENT ORDER");
        jPanel19.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 210, 30));

        jPanel21.add(jPanel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 172, 940, 370));

        m_dashboard.add(jPanel21, "card2");

        mainpanel.add(m_dashboard, "card8");

        m_orders.setBackground(new java.awt.Color(255, 255, 255));
        m_orders.setPreferredSize(new java.awt.Dimension(951, 503));
        m_orders.setLayout(new java.awt.CardLayout());

        mainOrderPanel.setLayout(new java.awt.CardLayout());

        nOrderPanel.setBackground(new java.awt.Color(255, 255, 255));
        nOrderPanel.setForeground(new java.awt.Color(255, 255, 255));
        nOrderPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btn_group.setBackground(new java.awt.Color(180, 136, 104));
        btn_group.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btn_newOrders.setBackground(new java.awt.Color(169, 118, 83));
        btn_newOrders.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_newOrders.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_newOrdersMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn_newOrdersMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn_newOrdersMouseExited(evt);
            }
        });
        btn_newOrders.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel24.setFont(new java.awt.Font("SansSerif", 1, 16)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setText("NEW ORDERS");
        btn_newOrders.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 140, 50));

        btn_group.add(btn_newOrders, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 220, -1));

        btn_inProgress.setBackground(new java.awt.Color(169, 118, 83));
        btn_inProgress.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_inProgress.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_inProgressMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn_inProgressMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn_inProgressMouseExited(evt);
            }
        });
        btn_inProgress.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel57.setFont(new java.awt.Font("SansSerif", 1, 16)); // NOI18N
        jLabel57.setForeground(new java.awt.Color(255, 255, 255));
        jLabel57.setText("IN PROGRESS");
        btn_inProgress.add(jLabel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 120, 50));

        btn_group.add(btn_inProgress, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 20, 220, -1));

        btn_cancelled.setBackground(new java.awt.Color(169, 118, 83));
        btn_cancelled.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_cancelled.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_cancelledMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn_cancelledMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn_cancelledMouseExited(evt);
            }
        });
        btn_cancelled.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel58.setFont(new java.awt.Font("SansSerif", 1, 16)); // NOI18N
        jLabel58.setForeground(new java.awt.Color(255, 255, 255));
        jLabel58.setText("CANCELLED");
        btn_cancelled.add(jLabel58, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, 120, 50));

        btn_group.add(btn_cancelled, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 20, 220, -1));

        btn_completed.setBackground(new java.awt.Color(169, 118, 83));
        btn_completed.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_completed.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_completedMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn_completedMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn_completedMouseExited(evt);
            }
        });
        btn_completed.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel32.setFont(new java.awt.Font("SansSerif", 1, 16)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(255, 255, 255));
        jLabel32.setText("COMPLETED");
        btn_completed.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 120, 50));

        btn_group.add(btn_completed, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 20, 220, -1));

        nOrderPanel.add(btn_group, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 950, 90));

        tabpanel.setLayout(new java.awt.CardLayout());

        newOrders.setBackground(new java.awt.Color(255, 255, 255));
        newOrders.setForeground(new java.awt.Color(153, 153, 153));
        newOrders.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel16.setBackground(new java.awt.Color(255, 255, 255));
        jPanel16.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextField3.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jTextField3.setText("Search Here");
        jTextField3.setPreferredSize(new java.awt.Dimension(77, 20));
        jPanel16.add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 15, 200, 30));

        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/S1.png"))); // NOI18N
        jPanel16.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 15, -1, 30));

        newOrders.add(jPanel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 110, 280, 50));

        jLabel34.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel34.setText("LIST OF NEW ORDERS");
        newOrders.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 211, 50));

        listOfNewOrders.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Order Numbers", "Status Of Orders", "num"
            }
        )
        {
            public boolean isCellEditable(int row, int column){
                return false;
            }
        }
    );
    listOfNewOrders.setEditingColumn(0);
    listOfNewOrders.setEditingRow(0);
    listOfNewOrders.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            listOfNewOrdersMouseClicked(evt);
        }
    });
    jScrollPane3.setViewportView(listOfNewOrders);

    newOrders.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 170, 820, 280));

    jPanel25.setBackground(new java.awt.Color(255, 255, 255));
    jPanel25.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jButton13.setBackground(new java.awt.Color(255, 255, 255));
    jButton13.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
    jButton13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/REFRESH.png"))); // NOI18N
    jButton13.setText("REFRESH");
    jButton13.setDoubleBuffered(true);
    jButton13.setFocusPainted(false);
    jButton13.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jButton13ActionPerformed(evt);
        }
    });
    jPanel25.add(jButton13, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 0, -1, 40));

    jButton14.setBackground(new java.awt.Color(255, 255, 255));
    jButton14.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
    jButton14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/Add_25px.png"))); // NOI18N
    jButton14.setText("ADD");
    jButton14.setBorderPainted(false);
    jButton14.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jButton14ActionPerformed(evt);
        }
    });
    jPanel25.add(jButton14, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 130, 40));

    jButton15.setBackground(new java.awt.Color(255, 255, 255));
    jButton15.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
    jButton15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/UPDATE1.png"))); // NOI18N
    jButton15.setText("UPDATE");
    jPanel25.add(jButton15, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 0, 130, 40));

    jButton16.setBackground(new java.awt.Color(255, 255, 255));
    jButton16.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
    jButton16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/DELETE.png"))); // NOI18N
    jButton16.setText("DELETE");
    jButton16.setBorderPainted(false);
    jButton16.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jButton16ActionPerformed(evt);
        }
    });
    jPanel25.add(jButton16, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 0, 130, 40));

    newOrders.add(jPanel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 550, 40));

    tabpanel.add(newOrders, "card2");

    inProgress_panel.setBackground(new java.awt.Color(255, 255, 255));
    inProgress_panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jPanel17.setBackground(new java.awt.Color(255, 255, 255));
    jPanel17.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jTextField4.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
    jTextField4.setText("Search Here");
    jTextField4.setPreferredSize(new java.awt.Dimension(77, 20));
    jPanel17.add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 5, 200, 40));

    jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/S1.png"))); // NOI18N
    jPanel17.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 5, -1, 40));

    inProgress_panel.add(jPanel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 70, 280, 50));

    jLabel35.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
    jLabel35.setText("LIST OF IN PROGRESS ORDERS");
    inProgress_panel.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 340, 50));

    tblProcessOrders.setModel(new javax.swing.table.DefaultTableModel(
        new Object [][] {
            {null, null, null, null},
            {null, null, null, null},
            {null, null, null, null},
            {null, null, null, null}
        },
        new String [] {
            "Title 1", "Title 2", "Title 3", "Title 4"
        }
    ));
    jScrollPane4.setViewportView(tblProcessOrders);

    inProgress_panel.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 930, 320));

    jPanel22.setBackground(new java.awt.Color(255, 255, 255));
    jPanel22.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jButton10.setBackground(new java.awt.Color(255, 255, 255));
    jButton10.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
    jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/REFRESH.png"))); // NOI18N
    jButton10.setText("REFRESH");
    jButton10.setDoubleBuffered(true);
    jButton10.setFocusPainted(false);
    jPanel22.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 0, -1, 40));

    jButton11.setBackground(new java.awt.Color(255, 255, 255));
    jButton11.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
    jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/DELETE.png"))); // NOI18N
    jButton11.setText("DELETE");
    jButton11.setBorderPainted(false);
    jButton11.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jButton11ActionPerformed(evt);
        }
    });
    jPanel22.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 130, 40));

    jButton12.setBackground(new java.awt.Color(255, 255, 255));
    jButton12.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
    jButton12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/UPDATE1.png"))); // NOI18N
    jButton12.setText("UPDATE");
    jPanel22.add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 0, 130, 40));

    inProgress_panel.add(jPanel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 74, 410, 40));

    tabpanel.add(inProgress_panel, "card3");

    cancelled_panel.setBackground(new java.awt.Color(255, 255, 255));
    cancelled_panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jPanel26.setBackground(new java.awt.Color(255, 255, 255));
    jPanel26.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jTextField5.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
    jTextField5.setText("Search Here");
    jTextField5.setPreferredSize(new java.awt.Dimension(77, 20));
    jPanel26.add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 5, 200, 40));

    jButton17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/S1.png"))); // NOI18N
    jPanel26.add(jButton17, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 5, -1, 40));

    cancelled_panel.add(jPanel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 70, 280, 50));

    jLabel36.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
    jLabel36.setText("LIST OF IN CANCELLED ORDERS");
    cancelled_panel.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 320, 50));

    jTable5.setModel(new javax.swing.table.DefaultTableModel(
        new Object [][] {
            {null, null, null, null},
            {null, null, null, null},
            {null, null, null, null},
            {null, null, null, null}
        },
        new String [] {
            "Title 1", "Title 2", "Title 3", "Title 4"
        }
    ));
    jScrollPane5.setViewportView(jTable5);

    cancelled_panel.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 930, 320));

    jPanel32.setBackground(new java.awt.Color(255, 255, 255));
    jPanel32.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jButton27.setBackground(new java.awt.Color(102, 153, 255));
    jButton27.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
    jButton27.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/REFRESH.png"))); // NOI18N
    jButton27.setText("REFRESH");
    jButton27.setDoubleBuffered(true);
    jButton27.setFocusPainted(false);
    jPanel32.add(jButton27, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 0, -1, 40));

    jButton30.setBackground(new java.awt.Color(255, 51, 51));
    jButton30.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
    jButton30.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/DELETE.png"))); // NOI18N
    jButton30.setText("DELETE");
    jButton30.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jButton30ActionPerformed(evt);
        }
    });
    jPanel32.add(jButton30, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 130, 40));

    jButton31.setBackground(new java.awt.Color(102, 153, 255));
    jButton31.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
    jButton31.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/UPDATE1.png"))); // NOI18N
    jButton31.setText("UPDATE");
    jPanel32.add(jButton31, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 0, 130, 40));

    cancelled_panel.add(jPanel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 74, 410, 40));

    tabpanel.add(cancelled_panel, "card4");

    completed_panel.setBackground(new java.awt.Color(255, 255, 255));
    completed_panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jPanel30.setBackground(new java.awt.Color(255, 255, 255));
    jPanel30.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jTextField7.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
    jTextField7.setText("Search Here");
    jTextField7.setPreferredSize(new java.awt.Dimension(77, 20));
    jPanel30.add(jTextField7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 5, 200, 40));

    jButton25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/S1.png"))); // NOI18N
    jPanel30.add(jButton25, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 5, -1, 40));

    completed_panel.add(jPanel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 70, 280, 50));

    jLabel38.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
    jLabel38.setText("LIST OF IN COMPLETED ORDERS");
    completed_panel.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 330, 50));

    jTable7.setModel(new javax.swing.table.DefaultTableModel(
        new Object [][] {
            {null, null, null, null},
            {null, null, null, null},
            {null, null, null, null},
            {null, null, null, null}
        },
        new String [] {
            "Title 1", "Title 2", "Title 3", "Title 4"
        }
    ));
    jScrollPane7.setViewportView(jTable7);

    completed_panel.add(jScrollPane7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 930, 320));

    jPanel31.setBackground(new java.awt.Color(255, 255, 255));
    jPanel31.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jButton26.setBackground(new java.awt.Color(255, 255, 255));
    jButton26.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
    jButton26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/REFRESH.png"))); // NOI18N
    jButton26.setText("REFRESH");
    jButton26.setDoubleBuffered(true);
    jButton26.setFocusPainted(false);
    jPanel31.add(jButton26, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 0, -1, 40));

    jButton28.setBackground(new java.awt.Color(255, 255, 255));
    jButton28.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
    jButton28.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/DELETE.png"))); // NOI18N
    jButton28.setText("DELETE");
    jButton28.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jButton28ActionPerformed(evt);
        }
    });
    jPanel31.add(jButton28, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 130, 40));

    jButton29.setBackground(new java.awt.Color(255, 255, 255));
    jButton29.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
    jButton29.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/UPDATE1.png"))); // NOI18N
    jButton29.setText("UPDATE");
    jPanel31.add(jButton29, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 0, 130, 40));

    completed_panel.add(jPanel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 74, 410, 40));

    tabpanel.add(completed_panel, "card5");

    nOrderPanel.add(tabpanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 950, 460));

    mainOrderPanel.add(nOrderPanel, "card2");

    m_orders.add(mainOrderPanel, "card2");

    mainpanel.add(m_orders, "card3");

    m_products.setBackground(new java.awt.Color(255, 255, 255));
    m_products.setPreferredSize(new java.awt.Dimension(951, 490));
    m_products.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jPanel20.setBackground(new java.awt.Color(255, 255, 255));
    jPanel20.setPreferredSize(new java.awt.Dimension(951, 490));
    jPanel20.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
    jPanel20.add(picture_path, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 350, 190, 70));

    producMainPanel.setBackground(new java.awt.Color(255, 255, 255));
    producMainPanel.setLayout(new java.awt.CardLayout());

    panelAddProduct.setBackground(new java.awt.Color(255, 51, 51));

    jPanel14.setBackground(new java.awt.Color(255, 255, 255));
    jPanel14.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jLabel59.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
    jLabel59.setText("Product name:");
    jPanel14.add(jLabel59, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 210, -1, -1));

    product_name1.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
    product_name1.setMargin(new java.awt.Insets(2, 5, 2, 2));
    product_name1.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            product_name1ActionPerformed(evt);
        }
    });
    jPanel14.add(product_name1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 200, 190, 30));

    jLabel60.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
    jLabel60.setText("Product Description:");
    jPanel14.add(jLabel60, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 250, -1, -1));

    product_description1.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
    jPanel14.add(product_description1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 240, 190, 30));

    jLabel61.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
    jLabel61.setText("Product Quantity:");
    jPanel14.add(jLabel61, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 290, -1, -1));

    product_quantity1.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
    jPanel14.add(product_quantity1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 280, 190, 30));

    jLabel62.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
    jLabel62.setText("Price:");
    jPanel14.add(jLabel62, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 330, -1, -1));

    product_price1.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
    jPanel14.add(product_price1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 320, 190, 30));

    jLabel63.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
    jLabel63.setText("Categories :");
    jPanel14.add(jLabel63, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 370, -1, -1));

    jLabel64.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
    jLabel64.setText("Status:");
    jPanel14.add(jLabel64, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 400, -1, -1));

    cmb_categories.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
    cmb_categories.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choose:" }));
    jPanel14.add(cmb_categories, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 360, 190, 30));

    jButton19.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
    jButton19.setText("Add");
    jPanel14.add(jButton19, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 460, 110, -1));

    jButton20.setText("Choose");
    jPanel14.add(jButton20, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 150, 90, -1));

    lblImages1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
    lblImages1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
    lblImages1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/Image_100px.png"))); // NOI18N
    lblImages1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
    jPanel14.add(lblImages1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 50, 110, 110));

    jRadioButton3.setBackground(new java.awt.Color(255, 255, 255));
    jRadioButton3.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
    jRadioButton3.setText("Availabale");
    jPanel14.add(jRadioButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 400, 80, -1));

    jRadioButton4.setBackground(new java.awt.Color(255, 255, 255));
    jRadioButton4.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
    jRadioButton4.setText("Not Availabale");
    jRadioButton4.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jRadioButton4ActionPerformed(evt);
        }
    });
    jPanel14.add(jRadioButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 400, 100, -1));

    jButton21.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
    jButton21.setText("Cancel");
    jPanel14.add(jButton21, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 460, 120, -1));

    jLabel3.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
    jLabel3.setText("ADD PRODUCT");
    jPanel14.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 160, 40));

    javax.swing.GroupLayout panelAddProductLayout = new javax.swing.GroupLayout(panelAddProduct);
    panelAddProduct.setLayout(panelAddProductLayout);
    panelAddProductLayout.setHorizontalGroup(
        panelAddProductLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(panelAddProductLayout.createSequentialGroup()
            .addGap(0, 0, Short.MAX_VALUE)
            .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(0, 0, Short.MAX_VALUE))
    );
    panelAddProductLayout.setVerticalGroup(
        panelAddProductLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(panelAddProductLayout.createSequentialGroup()
            .addGap(0, 0, Short.MAX_VALUE)
            .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(0, 0, Short.MAX_VALUE))
    );

    producMainPanel.add(panelAddProduct, "card2");

    panelAddCategories.setBackground(new java.awt.Color(51, 255, 0));

    jPanel12.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jLabel51.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
    jLabel51.setText("Category Name:");
    jPanel12.add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, -1, -1));

    product_name.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
    product_name.setMargin(new java.awt.Insets(2, 5, 2, 2));
    jPanel12.add(product_name, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 200, 200, 30));

    jLabel52.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
    jLabel52.setText("Category Description:");
    jPanel12.add(jLabel52, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 250, -1, -1));

    product_description.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
    jPanel12.add(product_description, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 240, 200, 30));

    jButton3.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
    jButton3.setText("Add");
    jPanel12.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 460, 110, -1));

    jButton2.setText("Choose");
    jPanel12.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 150, 90, -1));

    lblImages.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
    lblImages.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
    lblImages.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/Image_100px.png"))); // NOI18N
    lblImages.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
    jPanel12.add(lblImages, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 50, 110, 110));

    jButton18.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
    jButton18.setText("Cancel");
    jPanel12.add(jButton18, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 460, 120, -1));

    jLabel5.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
    jLabel5.setText("ADD CATEGORIES");
    jPanel12.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 250, 40));

    javax.swing.GroupLayout panelAddCategoriesLayout = new javax.swing.GroupLayout(panelAddCategories);
    panelAddCategories.setLayout(panelAddCategoriesLayout);
    panelAddCategoriesLayout.setHorizontalGroup(
        panelAddCategoriesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGap(0, 390, Short.MAX_VALUE)
        .addGroup(panelAddCategoriesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 390, Short.MAX_VALUE))
    );
    panelAddCategoriesLayout.setVerticalGroup(
        panelAddCategoriesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGap(0, 500, Short.MAX_VALUE)
        .addGroup(panelAddCategoriesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, 500, Short.MAX_VALUE))
    );

    producMainPanel.add(panelAddCategories, "card3");

    jPanel20.add(producMainPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 390, 500));

    jButton4.setBackground(new java.awt.Color(51, 204, 255));
    jButton4.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
    jButton4.setForeground(new java.awt.Color(255, 255, 255));
    jButton4.setText("ADD CATEGORIES");
    jButton4.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jButton4ActionPerformed(evt);
        }
    });
    jPanel20.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 10, 170, 30));

    jPanel3.setBackground(new java.awt.Color(255, 255, 255));

    jLabel4.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
    jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
    jLabel4.setText("PRODUCT DETAILS");

    javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
    jPanel3.setLayout(jPanel3Layout);
    jPanel3Layout.setHorizontalGroup(
        jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel3Layout.createSequentialGroup()
            .addContainerGap()
            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    );
    jPanel3Layout.setVerticalGroup(
        jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addContainerGap())
    );

    jPanel20.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 220, 50));

    jButton6.setBackground(new java.awt.Color(51, 204, 255));
    jButton6.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
    jButton6.setForeground(new java.awt.Color(255, 255, 255));
    jButton6.setText("ADD PRODUCT");
    jButton6.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jButton6ActionPerformed(evt);
        }
    });
    jPanel20.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 10, 160, 30));

    jPanel27.setBackground(new java.awt.Color(204, 204, 255));
    jPanel27.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jPanel2.setBackground(new java.awt.Color(255, 255, 255));
    jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jLabel6.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
    jLabel6.setText("SORT BY");
    jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

    cmbSort.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ascending", "Descending" }));
    cmbSort.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            cmbSortActionPerformed(evt);
        }
    });
    jPanel2.add(cmbSort, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 10, 80, -1));

    jTextField6.setText("Search");
    jPanel2.add(jTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 10, 130, -1));

    jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/search_20px.png"))); // NOI18N
    jButton1.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jButton1ActionPerformed(evt);
        }
    });
    jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 10, 30, 20));

    jPanel27.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 560, 40));

    jPanel29.setLayout(new java.awt.GridBagLayout());
    jScrollPane1.setViewportView(jPanel29);

    javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
    jPanel15.setLayout(jPanel15Layout);
    jPanel15Layout.setHorizontalGroup(
        jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 560, Short.MAX_VALUE)
    );
    jPanel15Layout.setVerticalGroup(
        jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 460, Short.MAX_VALUE)
    );

    jPanel27.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 560, 460));

    jPanel20.add(jPanel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 50, 560, 500));

    m_products.add(jPanel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 950, 550));

    mainpanel.add(m_products, "card4");

    jPanel5.setBackground(new java.awt.Color(51, 102, 0));

    listofOrderPanel1.setBackground(new java.awt.Color(255, 255, 255));
    listofOrderPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    productTable1.setModel(new javax.swing.table.DefaultTableModel(
        new Object [][] {
            {null, null, null, null},
            {null, null, null, null},
            {null, null, null, null},
            {null, null, null, null}
        },
        new String [] {
            "Product Name", "Quantity", "Price", "Categories"
        }
    ) {
        Class[] types = new Class [] {
            java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class
        };
        boolean[] canEdit = new boolean [] {
            false, false, false, false
        };

        public Class getColumnClass(int columnIndex) {
            return types [columnIndex];
        }

        public boolean isCellEditable(int rowIndex, int columnIndex) {
            return canEdit [columnIndex];
        }
    });
    jScrollPane8.setViewportView(productTable1);

    listofOrderPanel1.add(jScrollPane8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 620, 99));

    txt_search1.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            txt_search1ActionPerformed(evt);
        }
    });
    txt_search1.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyPressed(java.awt.event.KeyEvent evt) {
            txt_search1KeyPressed(evt);
        }
        public void keyReleased(java.awt.event.KeyEvent evt) {
            txt_search1KeyReleased(evt);
        }
        public void keyTyped(java.awt.event.KeyEvent evt) {
            txt_search1KeyTyped(evt);
        }
    });
    listofOrderPanel1.add(txt_search1, new org.netbeans.lib.awtextra.AbsoluteConstraints(429, 12, 112, -1));

    jButton7.setText("Search");
    jButton7.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jButton7ActionPerformed(evt);
        }
    });
    listofOrderPanel1.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(547, 11, -1, -1));

    listofOrderPanel1.add(jComboBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(75, 11, 110, -1));

    jLabel17.setText("FILTER BY");
    listofOrderPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 15, -1, -1));

    javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
    jPanel5.setLayout(jPanel5Layout);
    jPanel5Layout.setHorizontalGroup(
        jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGap(0, 620, Short.MAX_VALUE)
        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(listofOrderPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)))
    );
    jPanel5Layout.setVerticalGroup(
        jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGap(0, 302, Short.MAX_VALUE)
        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(listofOrderPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)))
    );

    javax.swing.GroupLayout m_promoLayout = new javax.swing.GroupLayout(m_promo);
    m_promo.setLayout(m_promoLayout);
    m_promoLayout.setHorizontalGroup(
        m_promoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGap(0, 950, Short.MAX_VALUE)
        .addGroup(m_promoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, m_promoLayout.createSequentialGroup()
                .addContainerGap(320, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
    );
    m_promoLayout.setVerticalGroup(
        m_promoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGap(0, 550, Short.MAX_VALUE)
        .addGroup(m_promoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, m_promoLayout.createSequentialGroup()
                .addContainerGap(225, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE)))
    );

    mainpanel.add(m_promo, "card6");

    m_users.setBackground(new java.awt.Color(255, 255, 255));
    m_users.setPreferredSize(new java.awt.Dimension(951, 490));
    m_users.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jPanel33.setBackground(new java.awt.Color(255, 255, 255));
    jPanel33.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    leaveBtn.setBackground(new java.awt.Color(255, 0, 51));
    leaveBtn.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jLabel25.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
    jLabel25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/leave_100px.png"))); // NOI18N
    leaveBtn.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 40, 90, 79));

    jLabel26.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
    jLabel26.setForeground(new java.awt.Color(255, 255, 255));
    jLabel26.setText("LEAVE");
    leaveBtn.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 14, 75, -1));

    jPanel34.setBackground(new java.awt.Color(0,0,0,30));
    jPanel34.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jLabel27.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
    jLabel27.setText("10");
    jPanel34.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 50, 30));

    leaveBtn.add(jPanel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 180, 30));

    jPanel33.add(leaveBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 40, 180, 160));

    userBtn.setBackground(new java.awt.Color(70, 88, 240));
    userBtn.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            userBtnMouseClicked(evt);
        }
        public void mouseEntered(java.awt.event.MouseEvent evt) {
            userBtnMouseEntered(evt);
        }
        public void mouseExited(java.awt.event.MouseEvent evt) {
            userBtnMouseExited(evt);
        }
    });
    userBtn.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jLabel29.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
    jLabel29.setForeground(new java.awt.Color(255, 255, 255));
    jLabel29.setText("USER");
    userBtn.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 14, 75, -1));

    jLabel31.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
    jLabel31.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/user_100px.png"))); // NOI18N
    userBtn.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 40, 90, 79));

    jLabel33.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
    jLabel33.setForeground(new java.awt.Color(255, 255, 255));
    jLabel33.setText("USER");
    userBtn.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 14, 75, -1));

    jPanel37.setBackground(new java.awt.Color(0,0,0,30));
    jPanel37.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jLabel37.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
    jLabel37.setText("10");
    jPanel37.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 50, 30));

    userBtn.add(jPanel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 180, 30));

    jPanel33.add(userBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 40, 180, 160));

    departmentBtn.setBackground(new java.awt.Color(204, 204, 0));
    departmentBtn.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jLabel42.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
    jLabel42.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/department_100px.png"))); // NOI18N
    departmentBtn.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 40, 90, 79));

    jPanel40.setBackground(new java.awt.Color(0,0,0,30));
    jPanel40.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jLabel71.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
    jLabel71.setText("10");
    jPanel40.add(jLabel71, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 50, 30));

    departmentBtn.add(jPanel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 180, 30));

    jLabel40.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
    jLabel40.setForeground(new java.awt.Color(255, 255, 255));
    jLabel40.setText("DEPARTMENT");
    departmentBtn.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 120, -1));

    jPanel33.add(departmentBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 40, 180, 160));

    noticeBtn.setBackground(new java.awt.Color(0, 153, 0));
    noticeBtn.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jLabel75.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
    jLabel75.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/urgent_message_100px.png"))); // NOI18N
    noticeBtn.add(jLabel75, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 40, 90, 79));

    jLabel76.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
    jLabel76.setForeground(new java.awt.Color(255, 255, 255));
    jLabel76.setText("NOTICE");
    noticeBtn.add(jLabel76, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 14, 75, -1));

    jPanel43.setBackground(new java.awt.Color(0,0,0,30));
    jPanel43.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jLabel77.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
    jLabel77.setText("10");
    jPanel43.add(jLabel77, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 50, 30));

    noticeBtn.add(jPanel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 180, 30));

    jPanel33.add(noticeBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 40, 180, 160));

    jPanel11.setBackground(new java.awt.Color(255, 255, 255));
    jPanel11.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jPanel13.setBackground(new java.awt.Color(153, 153, 255));
    jPanel13.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jLabel7.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
    jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
    jLabel7.setText("ATTENDANCE");
    jPanel13.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 4, 410, 20));

    jPanel11.add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 870, -1));

    jTable1.setModel(new javax.swing.table.DefaultTableModel(
        new Object [][] {

        },
        new String [] {
            "EID", "NAME", "EMAIL", "DEPARTMENT", "ROLE", "DATE IN", "Title 7"
        }
    ));
    jScrollPane6.setViewportView(jTable1);

    jPanel11.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 850, 140));

    jLabel9.setText("SEARCH");
    jPanel11.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 40, 50, 30));
    jPanel11.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 40, 120, 30));

    jButton5.setBackground(new java.awt.Color(255, 255, 255));
    jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/S1.png"))); // NOI18N
    jPanel11.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 40, 50, 30));

    jPanel33.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 240, 870, 230));

    m_users.add(jPanel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 950, 550));

    mainpanel.add(m_users, "card5");

    jPanel6.setBackground(new java.awt.Color(255, 0, 153));

    javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
    jPanel6.setLayout(jPanel6Layout);
    jPanel6Layout.setHorizontalGroup(
        jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGap(0, 429, Short.MAX_VALUE)
    );
    jPanel6Layout.setVerticalGroup(
        jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGap(0, 304, Short.MAX_VALUE)
    );

    javax.swing.GroupLayout m_reportsLayout = new javax.swing.GroupLayout(m_reports);
    m_reports.setLayout(m_reportsLayout);
    m_reportsLayout.setHorizontalGroup(
        m_reportsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGap(0, 950, Short.MAX_VALUE)
        .addGroup(m_reportsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, m_reportsLayout.createSequentialGroup()
                .addContainerGap(422, Short.MAX_VALUE)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(99, Short.MAX_VALUE)))
    );
    m_reportsLayout.setVerticalGroup(
        m_reportsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGap(0, 550, Short.MAX_VALUE)
        .addGroup(m_reportsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, m_reportsLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
    );

    mainpanel.add(m_reports, "card7");

    jPanel7.setBackground(new java.awt.Color(236, 211, 191));

    javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
    jPanel7.setLayout(jPanel7Layout);
    jPanel7Layout.setHorizontalGroup(
        jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGap(0, 318, Short.MAX_VALUE)
    );
    jPanel7Layout.setVerticalGroup(
        jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGap(0, 224, Short.MAX_VALUE)
    );

    javax.swing.GroupLayout m_settingsLayout = new javax.swing.GroupLayout(m_settings);
    m_settings.setLayout(m_settingsLayout);
    m_settingsLayout.setHorizontalGroup(
        m_settingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, m_settingsLayout.createSequentialGroup()
            .addContainerGap(415, Short.MAX_VALUE)
            .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(217, 217, 217))
    );
    m_settingsLayout.setVerticalGroup(
        m_settingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, m_settingsLayout.createSequentialGroup()
            .addContainerGap(210, Short.MAX_VALUE)
            .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(116, 116, 116))
    );

    mainpanel.add(m_settings, "card8");

    jPanel1.add(mainpanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 50, 950, 550));

    jPanel4.setBackground(new java.awt.Color(255, 255, 255));
    jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

    jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
    jLabel1.setText("Coffee now, Palpitate Later");
    jPanel4.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 270, 50));

    jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/Exit_32px.png"))); // NOI18N
    jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            jLabel2MouseClicked(evt);
        }
    });
    jPanel4.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 0, -1, 50));

    lblNumbeOfOrders.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
    lblNumbeOfOrders.setForeground(new java.awt.Color(255, 255, 255));
    lblNumbeOfOrders.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
    jPanel4.add(lblNumbeOfOrders, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 0, 30, 50));

    jLabel50.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javaapplication2/images/Notification_32px.png"))); // NOI18N
    jPanel4.add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 0, -1, 50));
    jPanel4.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 30, -1, -1));

    jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1180, 50));

    javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(
        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    );
    layout.setVerticalGroup(
        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    );

    setSize(new java.awt.Dimension(1178, 600));
    setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
      m_dashboard.setVisible(true);
       dash_hover.show(false);
       orders_hover.show(false);
       product_hover.show(false);
       users_hover.show(false);
       pc_hover.show(false);
       report_hover.show(false);
       settings_hover.show(false);
    }//GEN-LAST:event_formWindowOpened

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        int reply = JOptionPane.showConfirmDialog(null,"Are you Sure you want to quit?"," ",JOptionPane.YES_NO_OPTION);
        if(reply == JOptionPane.YES_OPTION){
            //FORMAT DATE
//            Date date1 =new Date();
//            LocalDate dateNow = LocalDate.now();
//            String currentDate = (DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.ENGLISH).format(dateNow));
//            String formattedDate = (DateTimeFormatter.ofPattern("E,MMM dd yyyy", Locale.ENGLISH).format(dateNow));
//                   
//                      
//                        //FORMAT TIME 
//            LocalTime timeNow = LocalTime.now();
//            String currentTime =  DateTimeFormatter.ofPattern("hh:mm:ss ",Locale.ENGLISH).format(timeNow);
//            String formattedTime = DateTimeFormatter.ofPattern("hh:mm a", Locale.ENGLISH).format(timeNow);
//            //INSERT TIME OUT
//            try{
//                String query = "UPDATE `user_timecard` SET `dateOut`= ?,`timeOut`= ?";
//                Connection conn = DbConnect.DBConnet();
//                pst = conn.prepareStatement(query);
//                pst.setString(1, formattedDate);
//                pst.setString(2, formattedTime);
//                int affectedRow = pst.executeUpdate();
//                if(affectedRow > 0){
//                     JOptionPane.showMessageDialog(null,"Hi "  + "\n Your TimeOut In : " + " " + formattedTime + " , " + formattedDate);
//                }
//            }
//            catch(Exception e){
//                System.out.println("Error" + e);
//            }
            //if()
            
           JOptionPane.showMessageDialog(null,"Time out show");
           this.dispose();
        }
       
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jPanel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel8MouseClicked
      
            m_orders.setVisible(true);
              m_dashboard.setVisible(false);
      
      
        m_products.setVisible(false);
        m_users.setVisible(false);
        m_promo.setVisible(false);
        m_reports.setVisible(false);
        m_settings.setVisible(false);
    }//GEN-LAST:event_jPanel8MouseClicked

    private void btn_completedMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_completedMouseExited
        btn_completed.setBackground(new Color(180,136,104));
    }//GEN-LAST:event_btn_completedMouseExited

    private void btn_completedMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_completedMouseEntered
        btn_completed.setBackground(new Color(199,146,100));
    }//GEN-LAST:event_btn_completedMouseEntered

    private void btn_completedMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_completedMouseClicked
        tabpanel.removeAll();
        tabpanel.repaint();
        tabpanel.revalidate();
        //ADD PANEL
        tabpanel.add(completed_panel);
        tabpanel.repaint();
        tabpanel.revalidate();
    }//GEN-LAST:event_btn_completedMouseClicked

    private void btn_cancelledMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_cancelledMouseExited
        btn_cancelled.setBackground(new Color(180,136,104));
    }//GEN-LAST:event_btn_cancelledMouseExited

    private void btn_cancelledMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_cancelledMouseEntered
        btn_cancelled.setBackground(new Color(199,146,100));
    }//GEN-LAST:event_btn_cancelledMouseEntered

    private void btn_cancelledMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_cancelledMouseClicked
        tabpanel.removeAll();
        tabpanel.repaint();
        tabpanel.revalidate();
        //ADD PANEL
        tabpanel.add(cancelled_panel);
        tabpanel.repaint();
        tabpanel.revalidate();
    }//GEN-LAST:event_btn_cancelledMouseClicked

    private void btn_inProgressMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_inProgressMouseExited
        btn_inProgress.setBackground(new Color(180,136,104));
    }//GEN-LAST:event_btn_inProgressMouseExited

    private void btn_inProgressMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_inProgressMouseEntered
        btn_inProgress.setBackground(new Color(199,146,100));
    }//GEN-LAST:event_btn_inProgressMouseEntered

    private void btn_inProgressMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_inProgressMouseClicked
        //newOrderPanel.setVisible(true);
        tabpanel.removeAll();
        tabpanel.repaint();
        tabpanel.revalidate();
        //ADD PANEL
        tabpanel.add(inProgress_panel);
        tabpanel.repaint();
        tabpanel.revalidate();
    }//GEN-LAST:event_btn_inProgressMouseClicked

    private void btn_newOrdersMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_newOrdersMouseExited
        btn_newOrders.setBackground(new Color(180,136,104));
    }//GEN-LAST:event_btn_newOrdersMouseExited

    private void btn_newOrdersMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_newOrdersMouseEntered
        btn_newOrders.setBackground(new Color(199,146,100));
    }//GEN-LAST:event_btn_newOrdersMouseEntered

    private void btn_newOrdersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_newOrdersMouseClicked
        //newOrderPanel.setVisible(true);
        tabpanel.removeAll();
        tabpanel.repaint();
        tabpanel.revalidate();
        //ADD PANEL
        tabpanel.add(newOrders);
        tabpanel.repaint();
        tabpanel.revalidate();
    }//GEN-LAST:event_btn_newOrdersMouseClicked

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
       menu m = new menu(this,true);
     
       m.setVisible(true);
       listOfNewOrders.revalidate();
//         listOfNewOrders.removeAll();
//      listOfNewOrders.revalidate();
////     
//      listOfNewOrders.validate();
//        getOrderNumberAndStatus();
//       listOfNewOrders.repaint();
         
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton16ActionPerformed

    private void settings_panelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_settings_panelMouseExited
        settings_hover.show(false);
        jLabel16.setVisible(true);
        jLabel48.setVisible(false);
        lbl_settings.setForeground(new Color(236,211,191));
    }//GEN-LAST:event_settings_panelMouseExited

    private void settings_panelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_settings_panelMouseEntered
        settings_hover.show(true);
        jLabel16.setVisible(false);
        jLabel48.setVisible(true);
        lbl_settings.setForeground(new Color(255,255,255));
    }//GEN-LAST:event_settings_panelMouseEntered

    private void settings_panelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_settings_panelMouseClicked
        m_dashboard.setVisible(false);
        m_orders.setVisible(false);
        m_products.setVisible(false);
        m_users.setVisible(false);
        m_promo.setVisible(false);
        m_reports.setVisible(false);
        m_settings.setVisible(true);
    }//GEN-LAST:event_settings_panelMouseClicked

    private void reports_panelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_reports_panelMouseExited
        report_hover.show(false);
        jLabel15.setVisible(true);
        jLabel47.setVisible(false);
        lbl_reports.setForeground(new Color(236,211,191));
    }//GEN-LAST:event_reports_panelMouseExited

    private void reports_panelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_reports_panelMouseEntered
        report_hover.show(true);
        jLabel15.setVisible(false);
        jLabel47.setVisible(true);
        lbl_reports.setForeground(new Color(255,255,255));
    }//GEN-LAST:event_reports_panelMouseEntered

    private void reports_panelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_reports_panelMouseClicked
        m_dashboard.setVisible(false);
        m_orders.setVisible(false);
        m_products.setVisible(false);
        m_users.setVisible(false);
        m_promo.setVisible(false);
        m_reports.setVisible(true);
        m_settings.setVisible(false);
    }//GEN-LAST:event_reports_panelMouseClicked

    private void promo_panelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_promo_panelMouseExited
        pc_hover.show(false);
        jLabel14.setVisible(true);
        jLabel46.setVisible(false);
        lbl_promocode.setForeground(new Color(236,211,191));
    }//GEN-LAST:event_promo_panelMouseExited

    private void promo_panelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_promo_panelMouseEntered
        pc_hover.show(true);
        jLabel14.setVisible(false);
        jLabel46.setVisible(true);
        lbl_promocode.setForeground(new Color(255,255,255));
    }//GEN-LAST:event_promo_panelMouseEntered

    private void promo_panelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_promo_panelMouseClicked
        m_dashboard.setVisible(false);
        m_orders.setVisible(false);
        m_products.setVisible(false);
        m_users.setVisible(false);
        m_promo.setVisible(true);
        m_reports.setVisible(false);
        m_settings.setVisible(false);
    }//GEN-LAST:event_promo_panelMouseClicked

    private void user_panelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_user_panelMouseExited
        users_hover.show(false);
        jLabel13.setVisible(true);
        jLabel45.setVisible(false);
        lbl_users.setForeground(new Color(236,211,191));
    }//GEN-LAST:event_user_panelMouseExited

    private void user_panelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_user_panelMouseEntered
        users_hover.show(true);
        jLabel13.setVisible(false);
        jLabel45.setVisible(true);
        lbl_users.setForeground(new Color(255,255,255));
    }//GEN-LAST:event_user_panelMouseEntered

    private void user_panelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_user_panelMouseClicked
        m_dashboard.setVisible(false);
        m_orders.setVisible(false);
        m_products.setVisible(false);
        m_users.setVisible(true);
        m_promo.setVisible(false);
        m_reports.setVisible(false);
        m_settings.setVisible(false);  // TODO add your handling code here:

    }//GEN-LAST:event_user_panelMouseClicked

    private void product_panelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_product_panelMouseExited
        product_hover.show(false);
        jLabel12.setVisible(true);
        jLabel44.setVisible(false);
        lbl_products.setForeground(new Color(236,211,191));
    }//GEN-LAST:event_product_panelMouseExited

    private void product_panelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_product_panelMouseEntered
        product_hover.show(true);
        jLabel12.setVisible(false);
        jLabel44.setVisible(true);
        lbl_products.setForeground(new Color(255,255,255));
    }//GEN-LAST:event_product_panelMouseEntered

    private void product_panelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_product_panelMouseClicked
        m_dashboard.setVisible(false);
        m_orders.setVisible(false);
        m_products.setVisible(true);
        m_users.setVisible(false);
        m_promo.setVisible(false);
        m_reports.setVisible(false);
        m_settings.setVisible(false);
    }//GEN-LAST:event_product_panelMouseClicked

    private void order_panelMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_order_panelMouseReleased
        //order_panel.setBackground(new Color(101,153,255));
    }//GEN-LAST:event_order_panelMouseReleased

    private void order_panelMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_order_panelMousePressed

    }//GEN-LAST:event_order_panelMousePressed

    private void order_panelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_order_panelMouseExited
        orders_hover.show(false);
        jLabel11.setVisible(true);
        jLabel43.setVisible(false);
        lbl_orders.setForeground(new Color(236,211,191));
    }//GEN-LAST:event_order_panelMouseExited

    private void order_panelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_order_panelMouseEntered
        orders_hover.show(true);
        jLabel11.setVisible(false);
        jLabel43.setVisible(true);
        lbl_orders.setForeground(new Color(255,255,255));
    }//GEN-LAST:event_order_panelMouseEntered

    private void order_panelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_order_panelMouseClicked
          
            m_orders.setVisible(true);
              m_dashboard.setVisible(false);
      
      
        m_products.setVisible(false);
        m_users.setVisible(false);
        m_promo.setVisible(false);
        m_reports.setVisible(false);
        m_settings.setVisible(false);
    }//GEN-LAST:event_order_panelMouseClicked

    private void dashboard_panelMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dashboard_panelMouseReleased

    }//GEN-LAST:event_dashboard_panelMouseReleased

    private void dashboard_panelMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dashboard_panelMousePressed

    }//GEN-LAST:event_dashboard_panelMousePressed

    private void dashboard_panelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dashboard_panelMouseExited
        dash_hover.show(false);
        icon_dashboard.setVisible(true);
        icon_dashboardWhite.setVisible(false);
        lbl_dashboard.setForeground(new Color(236,211,191));
    }//GEN-LAST:event_dashboard_panelMouseExited

    private void dashboard_panelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dashboard_panelMouseEntered
        dash_hover.show(true);
        icon_dashboard.setVisible(false);
        icon_dashboardWhite.setVisible(true);
        lbl_dashboard.setForeground(new Color(255,255,255));

    }//GEN-LAST:event_dashboard_panelMouseEntered

    private void dashboard_panelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dashboard_panelMouseClicked
        m_dashboard.setVisible(true);
        m_orders.setVisible(false);
        m_products.setVisible(false);
        m_users.setVisible(false);
        m_promo.setVisible(false);
        m_reports.setVisible(false);
        m_settings.setVisible(false);
       
       
//        m_dashboard.setFocusable(true);
//        lbl_dashboard.setForeground(new Color(255,255,255));
//        icon_dashboardWhite.setVisible(true);
//        icon_dashboard.hide();
//       
//        dashboard_panel.setBackground(Color.yellow);

        // JOptionPane.showMessageDialog(null,lbl_dashboard.getForeground());
    }//GEN-LAST:event_dashboard_panelMouseClicked

    private void dashboard_panelFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_dashboard_panelFocusGained
    
    }//GEN-LAST:event_dashboard_panelFocusGained

    private void jButton28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton28ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton28ActionPerformed

    private void jButton30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton30ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton30ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        producMainPanel.removeAll();
        producMainPanel.repaint();
        producMainPanel.revalidate();
        //ADD PANEL
        producMainPanel.add(panelAddCategories);
        producMainPanel.repaint();
        producMainPanel.revalidate();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        producMainPanel.removeAll();
        producMainPanel.repaint();
        producMainPanel.revalidate();
        //ADD PANEL
        producMainPanel.add(panelAddProduct);
        producMainPanel.repaint();
        producMainPanel.revalidate();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        listOfNewOrders.revalidate();
    }//GEN-LAST:event_jButton13ActionPerformed

    private void dashboard_panelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dashboard_panelKeyPressed
      dashboard_panel.setBackground(Color.red);
    }//GEN-LAST:event_dashboard_panelKeyPressed

    private void dashboard_panelKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dashboard_panelKeyReleased
        dashboard_panel.setBackground(Color.blue);
    }//GEN-LAST:event_dashboard_panelKeyReleased

    private void listOfNewOrdersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_listOfNewOrdersMouseClicked
     int selectRow = listOfNewOrders.getSelectedRow();
     TableModel model =listOfNewOrders.getModel();
     int getOrderNumber = (int)model.getValueAt(selectRow, 0);
     custom_confirmDialog confirmDialogs = new custom_confirmDialog(this,true);
     confirmDialogs.setProcessOrder(getOrderNumber);
     confirmDialogs.setVisible(true);
 
    }//GEN-LAST:event_listOfNewOrdersMouseClicked

    private void userBtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_userBtnMouseEntered
       
    }//GEN-LAST:event_userBtnMouseEntered

    private void userBtnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_userBtnMouseExited
       
    }//GEN-LAST:event_userBtnMouseExited

    private void txt_search1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_search1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_search1ActionPerformed

    private void txt_search1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_search1KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_search1KeyPressed

    private void txt_search1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_search1KeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_search1KeyReleased

    private void txt_search1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_search1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_search1KeyTyped

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7ActionPerformed

    private void product_name1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_product_name1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_product_name1ActionPerformed

    private void jRadioButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton4ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
     try{
         
               jPanel29.removeAll();
               String query = "select * from product";
               conn = DbConnect.DBConnect();
               pst = conn.prepareStatement(query);
             
              // ResultSet rst = pst.executeQuery();  
             rst = pst.executeQuery();
               GridBagConstraints gbc = new GridBagConstraints();
                    gbc.insets = new Insets(10,10,10,10);
                    int x = 0,y = 0;
                    gbc.gridx = 0;
                    gbc.gridy =0; 
                    int result = 1;
                while(rst.next()){
                    gbc.gridx = x; gbc.gridy = y;
                    productInfo p = new productInfo();
                    jPanel29.add(p,gbc);
                   result++;
                    String dbProductName = rst.getString("productName");
                    byte []dbProductImage = rst.getBytes("picture");
                    ImageIcon icon =  new ImageIcon(new ImageIcon(dbProductImage).getImage()
                    .getScaledInstance(150,100, Image.SCALE_SMOOTH));  
                    
                    p.setProductName(dbProductName);
                    p.setProductPrice(rst.getInt("price"));
                    p.setimages(icon);

                     x++;
                    if(x == 3){
                        x=0;
                        y++;
                    }
                
           }
        }catch(Exception e){
            System.out.println("Error" + e);
        }
            // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void cmbSortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbSortActionPerformed
        sortProducts();
    }//GEN-LAST:event_cmbSortActionPerformed

    private void userBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_userBtnMouseClicked
        ListOfEmployee listOfEmployee = new ListOfEmployee(this,true); 
        listOfEmployee.setVisible(true);
    }//GEN-LAST:event_userBtnMouseClicked
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Winddows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(userControlPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(userControlPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(userControlPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(userControlPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new userControlPanel().setVisible(true);
            }
        });
    }
    private int employeeID;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel btn_cancelled;
    private javax.swing.JPanel btn_completed;
    private javax.swing.JPanel btn_group;
    private javax.swing.JPanel btn_inProgress;
    private javax.swing.JPanel btn_newOrders;
    private javax.swing.JPanel cancelled_panel;
    private javax.swing.JComboBox<String> cmbSort;
    private javax.swing.JComboBox<String> cmb_categories;
    private javax.swing.JPanel completed_panel;
    private javax.swing.JPanel dash_hover;
    private javax.swing.JPanel dashboard_panel;
    private javax.swing.JPanel departmentBtn;
    private javax.swing.JLabel icon_dashboard;
    private javax.swing.JLabel icon_dashboardWhite;
    private javax.swing.JPanel inProgress_panel;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton25;
    private javax.swing.JButton jButton26;
    private javax.swing.JButton jButton27;
    private javax.swing.JButton jButton28;
    private javax.swing.JButton jButton29;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton30;
    private javax.swing.JButton jButton31;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel40;
    private javax.swing.JPanel jPanel43;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JRadioButton jRadioButton4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable5;
    private javax.swing.JTable jTable7;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    public static javax.swing.JLabel lblEmployeeName;
    private javax.swing.JLabel lblImages;
    private javax.swing.JLabel lblImages1;
    public static javax.swing.JLabel lblNumbeOfOrders;
    private javax.swing.JLabel lbl_dashboard;
    private javax.swing.JLabel lbl_orders;
    private javax.swing.JLabel lbl_products;
    private javax.swing.JLabel lbl_promocode;
    private javax.swing.JLabel lbl_reports;
    private javax.swing.JLabel lbl_settings;
    private javax.swing.JLabel lbl_users;
    private javax.swing.JPanel leaveBtn;
    private javax.swing.JTable listOfNewOrders;
    private javax.swing.JPanel listofOrderPanel1;
    private javax.swing.JPanel m_dashboard;
    public static javax.swing.JPanel m_orders;
    private javax.swing.JPanel m_products;
    private javax.swing.JPanel m_promo;
    private javax.swing.JPanel m_reports;
    private javax.swing.JPanel m_settings;
    private javax.swing.JPanel m_users;
    private javax.swing.JPanel mainOrderPanel;
    public static javax.swing.JPanel mainpanel;
    private javax.swing.JPanel menu;
    private javax.swing.JPanel nOrderPanel;
    private javax.swing.JPanel newOrders;
    private javax.swing.JPanel noticeBtn;
    public static javax.swing.JPanel order_panel;
    private javax.swing.JPanel orders_hover;
    private javax.swing.JPanel panelAddCategories;
    private javax.swing.JPanel panelAddProduct;
    private javax.swing.JPanel pc_hover;
    private javax.swing.JLabel picture_path;
    private javax.swing.JPanel producMainPanel;
    private javax.swing.JTable productTable1;
    private javax.swing.JTextField product_description;
    private javax.swing.JTextField product_description1;
    private javax.swing.JPanel product_hover;
    private javax.swing.JTextField product_name;
    private javax.swing.JTextField product_name1;
    private javax.swing.JPanel product_panel;
    private javax.swing.JTextField product_price1;
    private javax.swing.JTextField product_quantity1;
    private javax.swing.JPanel promo_panel;
    private javax.swing.JPanel report_hover;
    private javax.swing.JPanel reports_panel;
    private javax.swing.JPanel settings_hover;
    private javax.swing.JPanel settings_panel;
    private javax.swing.JPanel tabpanel;
    private javax.swing.JTable tblProcessOrders;
    private javax.swing.JTextField txt_search1;
    private javax.swing.JPanel userBtn;
    private javax.swing.JPanel user_panel;
    private javax.swing.JPanel users_hover;
    // End of variables declaration//GEN-END:variables

   class RoundedPanel extends JPanel
    {
        private Color backgroundColor;
        private int cornerRadius = 50;

        public RoundedPanel(LayoutManager layout, int radius) {
            super(layout);
            cornerRadius = radius;
        }

        public RoundedPanel(LayoutManager layout, int radius, Color bgColor) {
            super(layout);
            cornerRadius = radius;
            backgroundColor = bgColor;
        }

        public RoundedPanel(int radius) {
            super();
            cornerRadius = radius;
        }

        public RoundedPanel(int radius, Color bgColor) {
            super();
            cornerRadius = radius;
            backgroundColor = bgColor;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Dimension arcs = new Dimension(cornerRadius, cornerRadius);
            int width = getWidth();
            int height = getHeight();
            Graphics2D graphics = (Graphics2D) g;
            graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            //Draws the rounded panel with borders.
            if (backgroundColor != null) {
                graphics.setColor(backgroundColor);
            } else {
                graphics.setColor(getBackground());
            }
            graphics.fillRoundRect(0, 0, width-1, height, arcs.width, arcs.height); //paint background
            graphics.setColor(getForeground());
            graphics.drawRoundRect(0, 0, width-1, height-1, arcs.width, arcs.height); //paint border
            //jPanel5.setBounds(100,100,200,200);
        }
     }
}
