/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.awt.GridBagConstraints;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;
import static javaapplication2.orders.jPanel2;


import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Criz
 */
public final class menu extends javax.swing.JDialog {
private userControlPanel controlPanel;
Connection conn;
PreparedStatement pst;
ResultSet rst;
int db_OrderNumber, db_categoriesID,db_productID;
String productName,dbOrderStatus;
int db_getorderID,dbCountOrder,dbNumberOfOrders;

    /**
     * Creates new form menu
     * @param parent
     * @param modal
     */
    public menu(javaapplication2.userControlPanel parent, boolean modal) {
        super(parent, modal);
        controlPanel =parent;
        initComponents();
        listOfCategories();
        getOrderID();
    }

    public void getOrderID(){
         String orderNumber = lblOrderNumber.getText();
           try{
                   String queryforGetID = "SELECT orderID FROM orderdetails where ordernumber = ?";
                   conn = DbConnect.DBConnect();
                   pst= conn.prepareStatement(queryforGetID);
                  pst.setString(1, orderNumber);
                   rst = pst.executeQuery(); 
                   while(rst.next()){
                         db_getorderID = rst.getInt("orderID");
//                        System.out.println(db_getorderID);
                   }
                 }catch(Exception e){
                     System.out.println("Error " + e);
                 }
    }
    public void setLabel(int quantity){
        this.quantity = quantity;
        String abc = Integer.toString(quantity);
        lblTotal.setText(abc);
    
    }
    public int getLabel(){
        return quantity;
    }
    
    public void listOfCategories(){
        try{
            String query = "select * from categories";
            conn = DbConnect.DBConnect();
            pst = conn.prepareStatement(query);
            rst = pst.executeQuery();
            while(rst.next()){
                dbCategoryName = rst.getString("categoriesName");
                categories c = new categories();
                jPanel4.add(c);
               
                c.setCategoryName(dbCategoryName);
            }
        }catch(Exception e){
            System.out.println("Error" + e);
        }
    }
    public void getOrderNumber(){
        try{
            String query = "select max(orderNumber)as orderNumber from ORDERDETAILS";
            conn = DbConnect.DBConnect();
            pst = conn.prepareStatement(query);
            rst = pst.executeQuery();
            while(rst.next()){
                  db_OrderNumber = rst.getInt("orderNumber");
                  db_OrderNumber = db_OrderNumber+1;
                  //System.out.println("orderNumber"  + db_OrderNumber);
            }
        }catch(Exception e){
            System.out.println("Error" + e);
        }
    }
    public void getProductID(){
        try{
            //String categoryName = btnCategory.getText();
            String sql = "SELECT * FROM PRODUCT where productName = ?";
            conn = DbConnect.DBConnect();
            pst = conn.prepareStatement(sql);
            pst.setString(1, productName);
            rst =pst.executeQuery();
            while(rst.next()){  
                db_categoriesID = rst.getInt("CategoriesId");
                db_productID = rst.getInt("productID");
               
            }
        }catch(Exception e){
            System.out.println("Error" + e);
        }
    }
    public void insertPayment(){
        
    }
    
      String dbCategoryName;
      int dbCategoryID;
      menu(int dbCategoryID, String dbCategoryName) {
        this.dbCategoryID =dbCategoryID;
        this.dbCategoryName = dbCategoryName; 
        try{
           if(dbCategoryName.equalsIgnoreCase(dbCategoryName)) {
               jPanel6.removeAll();
               String query = "select * from product where categoriesID = ?";
               conn = DbConnect.DBConnect();
               pst = conn.prepareStatement(query);
               pst.setInt(1, dbCategoryID);
              // ResultSet rst = pst.executeQuery();  
             rst = pst.executeQuery();
               GridBagConstraints gbc = new GridBagConstraints();
                    gbc.insets = new Insets(10,10,10,10);
                    int x = 0,y = 0;
                    gbc.gridx = 0;
                    gbc.gridy =0; 
                    int result = 1;
                while(rst.next()){
                    gbc.gridx = x; gbc.gridy = y;
                    productInfo p = new productInfo();
                    jPanel6.add(p,gbc);
                   result++;
                    String dbProductName = rst.getString("productName");
                    byte []dbProductImage = rst.getBytes("picture");
                    ImageIcon icon =  new ImageIcon(new ImageIcon(dbProductImage).getImage()
                    .getScaledInstance(150,100, Image.SCALE_SMOOTH));  
                    
                    p.setProductName(dbProductName);
                    p.setProductPrice(rst.getInt("price"));
                    p.setimages(icon);

                     x++;
                    if(x == 3){
                        x=0;
                        y++;
                    }
                }
           }
        }catch(Exception e){
            System.out.println("Error" + e);
        }
    }
    public void getOrderStatusName(){
        try{
            String queryForGetOrderStatus = "SELECT COUNT(DISTINCT(orderD.orderNumber))as NumberOfOrders,orderStat.orderStatusDesc as OrderStatus FROM `ORDERSTATUS`as orderStat "
                                                          + "JOIN ORDERDETAILS as orderD ON orderStat.orderStatusID = orderD.orderStatusID "
                                                          + "WHERE orderD.orderStatusID = 4;";
            conn = DbConnect.DBConnect();
            pst = conn.prepareStatement(queryForGetOrderStatus);
            rst = pst.executeQuery();
            if(rst.next()){
                 dbCountOrder = rst.getInt("NumberOfOrders");
                 dbOrderStatus = rst.getString("OrderStatus");
            }
        }catch(Exception e){
            System.out.println("Error " + e);
        }
    }
    
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel6 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        listOfOrder = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        lblChange = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtcash = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        lblTotal = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        lblOrderNumber = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);
        addWindowFocusListener(new java.awt.event.WindowFocusListener() {
            public void windowGainedFocus(java.awt.event.WindowEvent evt) {
                formWindowGainedFocus(evt);
            }
            public void windowLostFocus(java.awt.event.WindowEvent evt) {
            }
        });
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
            public void windowDeactivated(java.awt.event.WindowEvent evt) {
                formWindowDeactivated(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 570, 40));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jScrollPane1.setAutoscrolls(true);

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setAutoscrolls(true);
        jPanel6.setMaximumSize(new java.awt.Dimension(600, 600));
        jPanel6.setLayout(new java.awt.GridBagLayout());
        jScrollPane1.setViewportView(jPanel6);

        jPanel3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 570, 460));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 570, 460));

        jPanel5.setBackground(new java.awt.Color(204, 255, 204));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        listOfOrder.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Order", "Qty", "Price", "Total"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        listOfOrder.setGridColor(new java.awt.Color(255, 255, 255));
        jScrollPane2.setViewportView(listOfOrder);

        jPanel5.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 430, 230));

        jButton1.setText("EDIT");
        jPanel5.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 10, -1, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton2.setText("CALCULATOR");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 10, 60, -1));
        jPanel1.add(lblChange, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 130, 210, 30));

        jLabel3.setText("TOTAL :");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, -1, -1));

        jLabel5.setText("AMOUNT :");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, -1, 20));

        txtcash.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcashActionPerformed(evt);
            }
        });
        txtcash.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtcashKeyTyped(evt);
            }
        });
        jPanel1.add(txtcash, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 90, 210, 30));

        jLabel6.setText("CHANGE : ");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, -1, 20));
        jPanel1.add(lblTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 50, 210, 30));

        jButton3.setText("CANCEL");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 190, 73, -1));

        jButton4.setText("DONE");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 190, 73, -1));

        jPanel5.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, 430, 220));
        jPanel5.add(lblOrderNumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 14, 100, 20));

        getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 30, 450, 500));

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1020, 30));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtcashActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcashActionPerformed
       double getTotal = Integer.valueOf(lblTotal.getText());
       double getAmount = Integer.valueOf(txtcash.getText());
       double change =  getAmount - getTotal;
              if(getTotal>getAmount){
                  JOptionPane.showMessageDialog(null, "You Don't have enough Money");
                  txtcash.setText("");
              } else{

                lblChange.setText(Double.toString(change));
              }

    }//GEN-LAST:event_txtcashActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        this.dispose();
        controlPanel.setFocusable(true);
         if(controlPanel.isFocusableWindow()==true){
              System.out.println("open");
                   //  controlPanel.m_orders.setVisible(true);
                  }else{
                      System.out.println("close");
                  }
                   getOrderStatusName();
//                   
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        //FORMAT DATE

            LocalDate dateNow = LocalDate.now();
            String currentDate = (DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.ENGLISH).format(dateNow));
                      //FORMAT TIME 
            LocalTime timeNow = LocalTime.now();
            String currentTime =  DateTimeFormatter.ofPattern("hh:mm:ss ",Locale.ENGLISH).format(timeNow);
                     
            int getTotal = 0;
            int sum=0;
            int execute = 0;
             int insertOrder = 0;
            int rowCount = menu.listOfOrder.getRowCount();
            String cash  = "";
            String totalChange = "";
            String totalAmount = "";
            String paymentType = "cash";
//                    ,totalChange,paymentType,totalAmount = null;
                
            
            for (int i=0;i <rowCount;i++){
             productName = (String) listOfOrder.getValueAt(i, 0);
            int productQuantity = (int) listOfOrder.getValueAt(i, 1);
            int productPrice = (int) listOfOrder.getValueAt(i, 2);
            int productTotal = (int) listOfOrder.getValueAt(i, 3);
        
            getOrderNumber();
            getProductID();
           
           
           String orderNumber = lblOrderNumber.getText();
            userControlPanel u= new userControlPanel();
            totalAmount = lblTotal.getText();
            cash = txtcash.getText();
            totalChange = lblChange.getText();

            try{
                
               String query = "INSERT INTO `orderdetails`(`orderNumber`, `categoriesID`, `productID`, `price`, `quantity`, `totalAmount`,orderStatusID) "
                                            + "VALUES (?,?,?,?,?,?,?)";
               conn = DbConnect.DBConnect();
               pst = conn.prepareStatement(query);
               pst.setString(1, orderNumber);
               pst.setInt(2, db_categoriesID);
               pst.setInt(3, db_productID);
               pst.setInt(4,productPrice);
               pst.setInt(5, productQuantity);
               pst.setInt(6,productTotal );
               pst.setInt(7, 4);
               
               insertOrder = pst.executeUpdate();
            }catch(Exception e){
                System.out.println("Error" + e);
      }
        } 
            if(insertOrder>0){
              String orderNumber = lblOrderNumber.getText();
                try{
                   String queryforGetID = "SELECT orderID FROM orderdetails where ordernumber = ?";
                   conn = DbConnect.DBConnect();
                   pst= conn.prepareStatement(queryforGetID);
                  pst.setString(1, orderNumber);
                   rst = pst.executeQuery(); 
                   while(rst.next()){
                         db_getorderID = rst.getInt("orderID");
                       System.out.println(db_getorderID);
                        controlPanel.getEmployeeID();
                        int employeeID = controlPanel.getID();
                        System.out.println("EmployeeID" + employeeID);
                        try{
                            
                        String queryForInsertPayment = "INSERT INTO `payment`(`orderID`, `cash`, `change`, `paymentDate`, `paymentTime`, `paymentType`, `employeeID`) "
                                                                  + "VALUES (?,?,?,?,?,?,?)";
                        conn = DbConnect.DBConnect();
                        pst = conn.prepareStatement(queryForInsertPayment);
                        pst.setInt(1, db_getorderID);
                        pst.setString(2, cash);
                        pst.setString(3, totalChange);
                        pst.setString(4, currentDate);
                        pst.setString(5, currentTime);
                        pst.setString(6, paymentType);
                        pst.setInt(7, employeeID);

                        execute = pst.executeUpdate();
                            }
                        catch(Exception e){
                            System.out.println("Error " + e);
                        }
                   // }
                   }
                 }catch(Exception e){
                     System.out.println("Error " + e);
                 }
  
        }
               if(execute>0){
                   JOptionPane.showMessageDialog(null, "Successfully Insert");
                   this.dispose();
                  controlPanel.refreshNewOrders();
 
               }else{
                   JOptionPane.showMessageDialog(null, "wrong statement");
               }

    }//GEN-LAST:event_jButton4ActionPerformed

    private void formWindowDeactivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowDeactivated
    
        
    }//GEN-LAST:event_formWindowDeactivated

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
   
    }//GEN-LAST:event_formWindowActivated

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        getOrderNumber();
        lblOrderNumber.setText(Integer.toString(db_OrderNumber));
//        int getRowCount = listOfOrder.getRowCount();
//        if(getRowCount>0){
//            System.out.println("greater sa zero");
//        }else{
//            jButton4.setEnabled(false);
//        }
    }//GEN-LAST:event_formWindowOpened

    private void formWindowGainedFocus(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowGainedFocus

    }//GEN-LAST:event_formWindowGainedFocus

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       getProductID();

    }//GEN-LAST:event_jButton2ActionPerformed

    private void txtcashKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtcashKeyTyped
          char vChar = evt.getKeyChar();
        if (!(Character.isDigit(vChar)
                || (vChar == KeyEvent.VK_BACK_SPACE)
                || (vChar == KeyEvent.VK_DELETE) 
               )) {
                evt.consume();
        }
    }//GEN-LAST:event_txtcashKeyTyped

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                menu dialog = new menu(new javaapplication2.userControlPanel(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }
    private int quantity;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    public static javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    public static javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    public static javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblChange;
    private javax.swing.JLabel lblOrderNumber;
    public static javax.swing.JLabel lblTotal;
    public static javax.swing.JTable listOfOrder;
    private javax.swing.JTextField txtcash;
    // End of variables declaration//GEN-END:variables
}
